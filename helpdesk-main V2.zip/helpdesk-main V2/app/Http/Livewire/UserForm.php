<?php

namespace App\Http\Livewire;

use Illuminate\Validation\Rule;
use Livewire\Component;
use Illuminate\Support\Facades\Validator;

class UserForm extends Component
{
    public $email;

    protected $rules = [
        'email' => ['required', 'email', 'unique:users,email', 'regex:/^.+@.+\..{2,}$/'],
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }
    
    public function render()
    {
        return view('livewire.user-form');
    }
}
