<?php

namespace App\Http\Controllers;

use App\Models\Sla;
use App\Models\User;
use App\Models\Ticket;
use App\Models\Project;
use App\Models\UserSkill;
use App\Mail\MailNotify;
use App\Mail\assigneeChange;
use App\Mail\NotifyCustomer;
use App\Models\Customer;
use App\Models\TicketActivity;
use App\Models\TicketWorkNote;
use App\Models\UserScore;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Providers\LogActivity as ProvidersLogActivity;
use GuzzleHttp\Client;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;



class TicketController extends Controller
{
    /**
     * __construct
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['permission:tickets.index|tickets.create|tickets.edit|tickets.delete']);
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->hasRole('Developer') || Auth::user()->hasRole('Senior Developer'))
        {
            $tickets = Ticket::where('assignee', Auth::id())->oldest()->when(request()->q, function($tickets) {
                $tickets = $tickets->where('problemsummary', 'like', '%'. request()->q . '%');
            })->paginate(5);
        } 
        else if(Auth::user()->hasRole('Customer'))
        {
            $customer = Customer::where('user_id',Auth::id())->oldest()->first();
            $tickets = Ticket::where('customer_id', $customer->id)->oldest()->when(request()->q, function($tickets) {
                $tickets = $tickets->where('problemsummary', 'like', '%'. request()->q . '%');
            })->paginate(5);
        }
        else {
            $tickets = Ticket::oldest()->when(request()->q, function($tickets) {
                $tickets = $tickets->where('problemsummary', 'like', '%'. request()->q . '%');
            })->paginate(5);
        }
        

        return view('tickets.index', compact('tickets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        if (Ticket::count() > 0) {
            // Get the highest ticket number and increment it by 1
            $highestTicket = Ticket::orderBy('id', 'desc')->first();
            $last_number = (int)Str::of($highestTicket->number)->after('TICK')->__toString();
            $ticketNo = 'TICK' . ($last_number + 1);
        } else {
            // If there are no tickets, set the ticket number to 1000
            $ticketNo = 'TICK' . 1000;
        }
        $customers = Customer::where('isActive', 1)->get();
        $slas = Sla::orderBy('id', 'asc')->get();
        $users = User::role('developer')->get();
        return view('tickets.create', compact('slas', 'users','ticketNo','customers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'ticket_no' => 'required',
            'updated_customer' => Auth::user()->hasRole('Customer') ? '' : 'required', // Validation depends on the user role
            'problemsummary' => 'required',
        ]);
        
        if (Auth::user()->hasRole('Customer')) {
            $customer = Customer::where('user_id', Auth::id())->oldest()->first(); // Execute the query
            $customerId = $customer->id;
        } else {
            $customerId = $request->input('updated_customer');
        }

        $customert = Customer::find($customerId);

        $ticket = Ticket::create([
            'number' => $request->input('ticket_no'),
            'sla_id' => $request->input('sla_id'),
            'openedby' => Auth::id(),
            'customer_id' => $customerId,
            'project_id' => $customert->project_id,
            'problemsummary' => $request->input('problemsummary'),
            'problemdetail' => $request->input('problemdetail'),
            'status' => 'New',
            // 'assignee' => $assignee,
            // 'assigneddate' => now(),
            // 'resolutiondate' => now()->addHours($resolutionHours),
            
         ]);

         if ($ticket) {

            $activityData = [
                'Project' => $ticket->project->name,              
                'status' => $ticket->status,              
                'Priority' => $ticket->sla->name,
                'Opened By' => $ticket->openedBy->firstname.' '.$ticket->openedBy->lastname,
                'Created' => $ticket->created_at,
            ];

            // Create TicketActivity record
            TicketActivity::create([
                'ticket_id' => $ticket->id,
                'activity_data' => $activityData,
                'user_id' => auth()->id(),
            ]);
            // $developer = User::findOrFail($assignee);
            $techLead = User::whereHas('roles', function ($query) {
                            $query->where('name', 'Tech Lead');
                        })
                        ->where('isActive', 1)
                        ->first();
            $customer = Customer::findOrFail($ticket->customer_id);
            $sla = Sla::findOrFail($ticket->sla_id);
            $project = Project::findOrFail($ticket->project_id);
            $user = Auth::user();
            $subject = 'Ticket - ' . $ticket->number;

            $assignee = null;
        
            // Send email using Laravel's Mail facade
            Mail::to($techLead->email)->send(new MailNotify($ticket,$customer,$sla,$project,$assignee));
        
            // Check if email was sent successfully
            if (Mail::failures()) {
                // Handle email sending failure
                return redirect()->route('tickets.index')->with(['error' => 'Failed to send email']);
            } else {
                // Log email activity or perform other actions
                event(new ProvidersLogActivity($user, $subject));
                return redirect()->route('tickets.index')->with(['success' => 'The ticket was successfully made']);
            }
        } else {
            return redirect()->route('tickets.index')->with(['error' => 'Tickets failed to be made']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ticketId = $id;

        // Retrieve work notes
        $workNotes = TicketWorkNote::where('ticket_id', $ticketId)
        ->whereNotNull('work_notes')
        ->orderBy('created_at')
        ->get();

        // Add type attribute to work notes
        $workNotesWithType = $workNotes->map(function ($workNote) {
        $workNote->setAttribute('type', 'work_note');
        return $workNote;
        });

        // Retrieve customer comments
        $customerComments = TicketWorkNote::where('ticket_id', $ticketId)
        ->whereNotNull('customer_comments')
        ->orderBy('created_at')
        ->get();

        // Add type attribute to customer comments
        $customerCommentsWithType = $customerComments->map(function ($comment) {
        $comment->setAttribute('type', 'customer_comment');
        return $comment;
        });

        // Merge the results with TicketActivity
        $activities = TicketActivity::where('ticket_id', $ticketId)
        ->select('id', 'ticket_id', 'created_at', 'activity_data', 'user_id')
        ->get()
        ->merge($workNotesWithType)
        ->merge($customerCommentsWithType)
        ->sortByDesc('created_at')
        ->values();



        // Retrieve the activities for the ticket with the given ID
        //$activities = TicketActivity::where('ticket_id', $id)->oldest()->get();
        $projects = Project::whereNotIn('status', ['Finished', 'Cancelled'])
                   ->orderBy('id', 'asc')
                   ->get();
        $ticket = Ticket::findOrFail($id);
        $slas = Sla::orderBy('id', 'asc')->get();
        $users = User::whereDoesntHave('roles', function ($query) {
            $query->where('name', 'Admin')
                  ->orWhere('name', 'Customer')
                  ->orWhere('name', 'Tech Lead');
        })
        ->where('isActive', 1)
        ->get();
        
        $customer = new Customer;
        return view('tickets.edit', compact('ticket', 'slas', 'users', 'customer','projects','activities'));
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'sla_id' => 'required',
            'problemsummary' => 'required',
            'resolutionHours' => 'required',
        ]);

        $ticket = Ticket::findOrFail($id);

        $currentAssignee = $ticket->assignee;

        //----TO ASSIGN DEVELOPERS AUTOMATICALLY-------//

        $project = Project::findOrFail($ticket->project_id);

        
        $slaId = $request->input('sla_id');
        $resolutionHours = $request->input('resolutionHours');

        //Get the tickets for the Project if exeist
        $completedTicketsForProject = Ticket::where('project_id', $ticket->project_id)
        ->get();

        // Get IDs of previous tickets
        $completedTicketsForProjectIds = $completedTicketsForProject->pluck('id');

        // Get the ticket activities of the completed tickets
        $latestActivitiesSubquery = DB::table('ticket_activities')
            ->select('ticket_id', DB::raw('MAX(id) as latest_id'))
            ->whereIn('ticket_id', $completedTicketsForProjectIds)
            ->groupBy('ticket_id');

        $ticketActivities = TicketActivity::whereIn('id', function ($query) use ($latestActivitiesSubquery) {
                $query->select('latest_id')
                    ->from(DB::raw("({$latestActivitiesSubquery->toSql()}) as latest_activities"))
                    ->mergeBindings($latestActivitiesSubquery)
                    ->where(function ($query) {
                        $query->whereRaw('JSON_CONTAINS_PATH(activity_data, "one", "$.Assigned to")')
                            ->where(function ($query) {
                                $query->whereRaw('JSON_UNQUOTE(JSON_EXTRACT(activity_data, "$.Status")) IS NULL')
                                    ->orWhereRaw('JSON_UNQUOTE(JSON_EXTRACT(activity_data, "$.Status")) NOT IN ("To be Tested", "To be Deployed", "Cancelled")');
                            });
                    });
            })
            ->get();

        //Get the assinee details who completed the tickets 
        $ticketAssigneeDetails = $ticketActivities->map(function ($activity) {
            $assignedTo = $activity->activity_data['Assigned to'] ?? null;

            if ($assignedTo) {
                list($firstName, $lastName) = explode(' ', $assignedTo, 2);
                $user = User::where('firstname', $firstName)
                    ->where('lastname', $lastName)
                    ->where('isActive', 1)
                    ->first();  

                return $user;            
            } 
            return null; 

        })->filter()->unique('id')->values();
        
        
        if ($slaId == 3 || $slaId == 4) {
            //FOR JUNIOR DEVELOPERS
            $juniorDevelopers = User::whereHas('roles', function ($query) {
                $query->whereIn('name', ['Developer', 'Junior Developer']);
            })
            ->where('isActive', 1)
            ->get();            
            

            // Step 1: Sort by role, giving priority to Developer over Junior Developer
            $juniorDeveloperIds = $juniorDevelopers->sortBy(function ($user) {
                return $user->roles->contains('name', 'Developer') ? 0 : 1;
            })->pluck('id')->toArray();   

            // Step 2: Get previous experienced developers (from ticket assignees)
            $experiencedDeveloperIds = $ticketAssigneeDetails->pluck('id')->toArray();
            $experiencedDevelopers = array_filter($juniorDeveloperIds, function ($developerId) use ($experiencedDeveloperIds) {
                return in_array($developerId, $experiencedDeveloperIds);
            });

            // Step 3: If no experienced developers found, fallback to juniorDeveloperIds
            if (count($experiencedDevelopers) !== 0) {
                $experiencedDevelopers = array_values($experiencedDevelopers);
            } else {
                $experiencedDevelopers = $juniorDeveloperIds;
            }

            // Step 4: Filter developers who have enough available hours
            $developersWithEnoughHours = [];
            foreach ($experiencedDevelopers as $developerId) {
                $developerTickets = Ticket::where('assignee', $developerId)
                            ->where('status', 'Assigned')
                            ->get();
                $totalHoursSpent = $developerTickets->sum('resolutionHours');
                $freeTime = 40 - $totalHoursSpent;

                // Check if the developer has enough free time
                if ($freeTime >= $resolutionHours) {
                    // Store developer ID along with their free time
                    $developersWithEnoughHours[] = [
                        'developerId' => $developerId,
                        'freeTime' => $freeTime,
                    ];
                }
            }

            // Step 5: Sort developers by free time (descending order)
            usort($developersWithEnoughHours, function ($a, $b) {
                return $b['freeTime'] - $a['freeTime'];
            });

            // Step 6: Assign the developer with the most free time, or fallback to the first Developer
            if (!empty($developersWithEnoughHours)) {
                // Get the first developer ID (the one with the most free time)
                $assignee = $developersWithEnoughHours[0]['developerId'];
            } else {
                // Fallback: Assign the first developer (or junior developer)
                $assignee = $juniorDeveloperIds[0];
            }

        }
        else{
            //FOR SENIOR DEVELOPERS
            // If the SLA is 1 or 2, assign to Senior developers
            // Step 1: Fetch active developers with roles ordered by Senior Developer first
            $seniorDevelopers = User::whereHas('roles', function ($query) {
                $query->whereIn('name', ['Senior Developer', 'Developer']);
            })
            ->where('isActive', 1)
            ->get();

            // Step 2: Get IDs of Senior Developers and Developers
            $seniorDeveloperIds = $seniorDevelopers->sortBy(function ($user) {
                // Sort users, ensuring Senior Developers come before Developers
                return $user->roles->contains('name', 'Senior Developer') ? 0 : 1;
            })
            ->pluck('id')
            ->toArray(); 

            // Step 3: Get IDs of previously experienced developers (from ticket assignees)
            $experiencedDeveloperIds = $ticketAssigneeDetails->pluck('id')->toArray();
            $experiencedDevelopers = array_filter($seniorDeveloperIds, function ($developerId) use ($experiencedDeveloperIds) {
                return in_array($developerId, $experiencedDeveloperIds);
            });            

            // Step 4: If no experienced developers found, fallback to seniorDeveloperIds
            if (count($experiencedDevelopers) !== 0) {
                $experiencedDevelopers = array_values($experiencedDevelopers);
            } else {
                $experiencedDevelopers = $seniorDeveloperIds;
            }

            // Step 5: Filter developers who have enough available hours
            $developersWithEnoughHours = [];
            foreach ($experiencedDevelopers as $developerId) {
                $developerTickets = Ticket::where('assignee', $developerId)
                            ->where('status', 'Assigned')
                            ->get();
                $totalHoursSpent = $developerTickets->sum('resolutionHours');
                $freeTime = 40 - $totalHoursSpent;

                // Check if the developer has enough free time
                if ($freeTime >= $resolutionHours) {
                    // Store developer ID along with their free time
                    $developersWithEnoughHours[] = [
                        'developerId' => $developerId,
                        'freeTime' => $freeTime,
                    ];
                }
            }

            // Step 6: Sort developers by free time (descending order)
            usort($developersWithEnoughHours, function ($a, $b) {
                return $b['freeTime'] - $a['freeTime'];
            });

            // Step 7: Assign the developer with the most free time, or fallback to the first Senior Developer
            if (!empty($developersWithEnoughHours)) {
                // Get the first developer ID (the one with the most free time)
                $assignee = $developersWithEnoughHours[0]['developerId'];
            } else {
                // Fallback: Assign the first senior developer
                $assignee = $seniorDeveloperIds[0];
            }
        }




        $request->merge(['assignee' => $assignee]);

        // $request->merge(['assignee' => 3]);
       
        

        //--------------------------------------------//
        // Get the original ticket data
        $originalData = $ticket->getOriginal();

        // Initialize an array to store the changed data
        $changedData = [];

        // Define the fields to check for changes
        $fieldsToCheck = ['sla_id', 'problemsummary', 'problemdetail', 'assignee', 'status', 'resolutionHours'];
        
        //Passing the assignee to the changedData
        // $changedData['assignee'] = $assignee;

        // Iterate over the fields and check if they have changed
        foreach ($fieldsToCheck as $field) {
            if ($request->has($field) && $originalData[$field] != $request->input($field)) {
                $changedData[$field] = $request->input($field);

                // If the assignee has been changed, change the assigned date and resolutiondate
                if ($field == 'assignee') {
                    $ticket->update([
                        'assigneddate' => now(),
                        'resolutiondate' => now()->addHours($request->input('resolutionHours'))
                    ]);
                } 
                // If the resolutionHours has been changed, change the  resolutiondate
                else if ($field == 'resolutionHours') {
                    $ticket->update([
                        'resolutiondate' => now()->addHours($request->input('resolutionHours'))
                    ]);
                }
                
            }
        }

        
        // Update the ticket with the changed data
        $ticket->update($changedData);

        $newStatus = $ticket->getOriginal('status');         
        // Get the new assignee
        $assignee = User::findOrFail($ticket->assignee);

        $customer = Customer::findOrFail($ticket->customer_id);
        $sla = Sla::findOrFail($ticket->sla_id);
        $project = Project::findOrFail($ticket->project_id);

        if ($newStatus == 'Closed' || $newStatus == 'Cancelled') {            
            $ticket->update([
                'resolveddate' => now(),
                //'progress_percentage' => $request->input('progressPercentage'),
            ]);

            //TO MAIL CUSTOMER WHEN TICKET IS CLOSED OR CANCELLED
        
            Mail::to($customer->email)->send(new NotifyCustomer($ticket,$assignee,$customer,$sla,$project));
        
            if (Mail::failures()) {
                return redirect()->route('tickets.index')->with(['error' => 'Failed to send email']);
            }
        
        } 
        else if ($newStatus == 'To be Tested'){

        }
        else if ($newStatus == 'To be Deployed'){

        }

        if($ticket){

            if($currentAssignee == null){
                
                Mail::to($assignee->email)->send(new MailNotify($ticket,$customer,$sla,$project,$assignee));
                        
                // Check if email was sent successfully
                if (Mail::failures()) {
                    // Handle email sending failure
                    return redirect()->route('tickets.index')->with(['error' => 'Failed to send email']);
                }
            }
            // Check if the assignee has changed
            else if($currentAssignee != $assignee->id) {
            
                Mail::to($assignee->email)->send(new assigneeChange($ticket,$assignee,$customer,$sla,$project));
            
                if (Mail::failures()) {
                    return redirect()->route('tickets.index')->with(['error' => 'Failed to send email']);
                }
            }

            // Initialize an array to store the activity data
            $activityData = [];

            // Define the keys corresponding to the fields in the activity data
            $keys = [
                'assignee' => 'Assigned to',
                'resolutionHours' => 'Resolution Hours',
                'status' => 'Status',
                'sla_id' => 'Priority',
            ];

            foreach ($keys as $field => $key) {
                if (array_key_exists($field, $changedData)) {
                    if ($field === 'assignee' && isset($ticket->assigneeUser)) {
                        $activityData[$key] = $ticket->assigneeUser->firstname.' '.$ticket->assigneeUser->lastname;
                    } elseif ($field === 'sla_id' && isset($ticket->sla)) {
                        $activityData[$key] = $ticket->sla->name;
                    } else {
                        // If it's not 'assignee' or 'sla_id', just store the value as is
                        $activityData[$key] = $changedData[$field];
                    }
                }
            }

            // Check if activityData is not empty
            if (!empty($activityData)) {
                // Create TicketActivity record
                TicketActivity::create([
                    'ticket_id' => $ticket->id,
                    'activity_data' => $activityData,
                    'user_id' => auth()->id(),
                ]);
            }

            
            if ($request->filled('worknotes') || $request->filled('customer_comments')) {
                TicketWorkNote::create([
                    'ticket_id' => $ticket->id,
                    'work_notes' => $request->input('worknotes'),
                    'customer_comments' => $request->input('customer_comments'),
                    'user_id' => auth()->id(),
                ]);
            }
            

            return redirect()->route('tickets.index')->with(['success' => 'The ticket was successfully updated!']);
        }else{
            return redirect()->route('tickets.index')->with(['error' => 'Failed!']);
        }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ticket = Ticket::findOrFail($id);
        $ticket->delete();

        if($ticket){
            $user = Auth::user();
            $subject = 'Delete tickets no '. $ticket->number;
            event(new ProvidersLogActivity($user, $subject));
            return response()->json([
                'status' => 'success'
            ]);
        }else{
            return response()->json([
                'status' => 'error'
            ]);
        }
    }

    // public function storeActivity(Request $request, $ticketId)
    // {
    //     // Validate incoming request
    //     $validatedData = $request->validate([
    //         'activity_data' => 'required|array',
    //     ]);

    //     // Store ticket activity
    //     $activity = new TicketActivity();
    //     $activity->ticket_id = $ticketId;
    //     $activity->activity_data = $validatedData['activity_data'];
    //     $activity->user_id = auth()->id(); // Assuming user is authenticated
    //     $activity->save();

    //     return response()->json(['message' => 'Activity saved successfully'], 201);
    // }
}
