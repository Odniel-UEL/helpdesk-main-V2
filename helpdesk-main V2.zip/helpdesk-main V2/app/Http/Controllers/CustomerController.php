<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\User;
use App\Models\Project;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    /**
     * __construct
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['permission:customers.index|customers.create|customers.edit|customers.delete']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        
        $customers = Customer::oldest()->when(request()->q, function($customers) {
            $customers = $customers->where('firstname', 'like', '%'. request()->q . '%');
        })
        ->where('isActive', 1)
        ->paginate(5);

        return view('customers.index', compact('customers'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $projects = Project::whereNotIn('status', ['Finished', 'Cancelled'])
                   ->orderBy('id', 'asc')
                   ->get();
        return view('customers.create', compact('projects'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'firstname'     => 'required',
            'lastname'     => 'required',
            'address'   => 'required',
            'project'   => 'required',
            'phone'   => 'required|max:15',
            'email'   => 'required|email|unique:users',
        ]);


        $user = User::create([
            'firstname' => $request->firstname,
            'lastname'  => $request->lastname,
            'email'     => $request->email,
            'password'  => bcrypt('password'),
        ]);

        //assign role
        $user->assignRole(5);

        if($user){
            $customers = Customer::create([
                'user_id'     => $user->id,
                'firstname'     => $request->firstname,
                'lastname'     => $request->lastname,
                'address'     => $request->address,
                'phone'     => $request->phone,
                'email'     => $request->email,              
                'project_id'     => $request->project,
                'isActive'     => 1,
            ]);
            if($customers){
                return redirect()->route('customers.index')->with(['success' => 'The data is successfully stored!']);
            }else{
                return redirect()->route('customers.index')->with(['error' => 'Failed!']);
            }
        }else{
            return redirect()->route('customers.index')->with(['error' => 'Failed!']);
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $projects = Project::whereNotIn('status', ['Finished', 'Cancelled'])
                   ->orderBy('id', 'asc')
                   ->get();
        $customer = Customer::findOrFail($id);
        return view('customers.edit', compact('customer','projects'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $customer = Customer::findOrFail($id);
        $this->validate($request, [
            'firstname'     => 'required',
            'lastname'     => 'required',
            'address'   => 'required',
            'phone'   => 'required|max:15',
            'email'   => 'required|email|unique:customers,email,'.$customer->id,
            'isActive'   => 'required',
        ]);

        
        $user = User::where('email', $customer->email);

        $user->update([
            'firstname'      => $request->firstname,
            'lastname'      => $request->lastname,
            'email'     => $request->email,
            'isActive'     => $request->isActive
        ]);     
        
        if($user){
            $customer->update([
                'firstname'     => $request->firstname,
                'lastname'     => $request->lastname,
                'address'     => $request->address,
                'phone'     => $request->phone,
                'email'     => $request->email,
                'isActive'     => $request->isActive,
            ]);
    
            if($customer){
                //redirect dengan pesan sukses
                return redirect()->route('customers.index')->with(['success' => 'The data is successfully updated!']);
            }else{
                //redirect dengan pesan error
                return redirect()->route('customers.index')->with(['error' => 'Failed!']);
            }
        }
        else{
            return redirect()->route('customers.index')->with(['error' => 'Failed!']);
        }

        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customer = Customer::findOrFail($id);

        $customer->update(['isActive' => 0]);


        if($customer->wasChanged('isActive')) {
            //To update users table
            $customer->user()->update(['isActive' => 0]);

            return response()->json(['status' => 'success']);

        } else {
            return response()->json(['status' => 'error']);
        }
        
    }
}
