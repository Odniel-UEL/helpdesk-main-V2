<?php

namespace App\Http\Controllers;


use App\Models\Customer;

use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Ticket;
use App\Models\User;

class ReportController extends Controller
{

    public function __construct()
    {
        $this->middleware(['permission:reports.customerWise|reports.developerWise']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function customerWise()
    {
        $customers = Customer::where('isActive', 1)->get();
        return view('reports.customerWise', compact('customers'));
    }

    public function getProjects($customerId)
    {
        $customer = Customer::find($customerId);

        if($customer) {
            $project = $customer->project; 
            return response()->json(['project_name' => $project ? $project->name : '']);
        } else {
            return response()->json([], 404); // Return empty array if no customer found
        }
        // return response()->json($projects);
    }

    public function generateCustomerReport(Request $request)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'date_range' => 'required|string|regex:/^\d{4}-\d{2}-\d{2}\sto\s\d{4}-\d{2}-\d{2}$/',
            'customer_id' => 'required|exists:customers,id',
            'project' => 'required|string'
        ]);

        // Process the date range
        [$startDate, $endDate] = explode(' to ', $validated['date_range']);

        // Fetch tickets for the customer within the date range
        $tickets = Ticket::with(['sla','project'])->where('customer_id', $validated['customer_id'])
                        ->whereBetween('created_at', [$startDate, $endDate])
                        ->get();

        // Return the tickets as a JSON response
        return response()->json($tickets);
    }

    public function developerWise()
    {

        $developers = User::whereHas('roles', function ($query) {
            $query->whereIn('name', ['Senior Developer','Developer', 'Junior Developer']);
        })
        ->where('isActive', 1)
        ->get();
        return view('reports.developerWise', compact('developers'));
    }
    public function generateDeveloperReport(Request $request)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'date_range' => 'required|string|regex:/^\d{4}-\d{2}-\d{2}\sto\s\d{4}-\d{2}-\d{2}$/',
            'developer_id' => 'required|exists:users,id',
        ]);

        // Process the date range
        [$startDate, $endDate] = explode(' to ', $validated['date_range']);

        // Fetch tickets for the customer within the date range
        $tickets = Ticket::with(['sla','project'])->where('assignee', $validated['developer_id'])
                        ->whereBetween('created_at', [$startDate, $endDate])
                        ->get();

        // Return the tickets as a JSON response
        return response()->json($tickets);
    }

}
