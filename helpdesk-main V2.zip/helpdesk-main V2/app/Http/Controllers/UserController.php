<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserSkill;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * __construct
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('permission:users.index|users.create|users.edit|users.delete',['only' => ['index', 'create', 'edit', 'delete']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::oldest()
                ->when(request()->q, function ($query) {
                    $query->where('firstname', 'like', '%' . request()->q . '%');
                })
                ->where('isActive', 1)
                ->whereDoesntHave('roles', function ($query) {
                    $query->where('name', 'Customer');
                })
                ->paginate(5);

        return view('users.index', compact('users'));
    }

    public function getUsers(Request $request)
    {
        $query = $request->get('query');
        $users = User::whereDoesntHave('roles', function ($query) {
            $query->where('name', 'Admin')
                  ->orWhere('name', 'Customer')
                  ->orWhere('name', 'Tech Lead');
        })
        ->where('isActive', 1)
        ->where('firstname', 'like', '%' . $query . '%')->pluck('firstname')->toArray();
        
        return response()->json($users);
    }
 
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // $skills = ['React', 'Angular', 'PHP', 'Python', 'Ruby', 'Java', 'C#', 'Swift'];
        $roles = Role::where('name', '!=', 'Customer')->get();
        return view('users.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'firstname' => 'required',
            'lastname'  => 'required',
            'email'     => ['required', 'email', 'unique:users,email', 'regex:/^.+@.+\..{2,}$/'],
            'password'  => 'required|confirmed',
            // 'technologies' => 'nullable|array',
        ]);

        $user = User::create([
            'firstname' => $request->input('firstname'),
            'lastname'  => $request->input('lastname'),
            'email'     => $request->input('email'),
            'password'  => bcrypt($request->input('password')),
            'isActive'  => 1
        ]);


        // Assuming $user is the user for whom skills are being stored
        $selectedRoles = collect($request->input('role'));

        // Check if any of the selected roles match developer, senior developer, or tech lead
        // if ($selectedRoles->contains('Developer') || $selectedRoles->contains('Senior Developer') || $selectedRoles->contains('Tech Lead')) {
        //     // Convert selected skills to JSON
        //     $skills = json_encode($request->skills);

        //     // Create a new record in the user_skill table
        //     $userSkill = UserSkill::create([
        //         'user_id' => $user->id,
        //         'technologies' => $skills,
        //     ]);

        // }

        //assign role
        $user->assignRole($request->input('role'));

        if($user){
            //redirect dengan pesan sukses
            return redirect()->route('users.index')->with(['success' => 'The data is successfully stored!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('users.index')->with(['error' => 'Failed!']);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        // $skills = ['React', 'Angular', 'PHP', 'Python', 'Ruby', 'Java', 'C#', 'Swift'];
        $roles = Role::where('name', '!=', 'Customer')->get();
        // Fetch the user's skills
        // $userSkills = UserSkill::where('user_id', $user->id)->pluck('technologies')->first();
        return view('users.edit', compact('user', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        $this->validate($request, [
            'firstname'      => 'required',
            'lastname'      => 'required',
            'isActive'      => 'required',
            'email' => ['email', 'unique:users,email,'.$user->id, 'regex:/^.+@.+\..{2,}$/'],
            // 'skills' => 'nullable|array',
        ]);

        $user = User::findOrFail($user->id);

        if($request->input('password') == "") {
            $user->update([
                'firstname'      => $request->input('firstname'),
                'lastname'      => $request->input('lastname'),
                'email'     => $request->input('email'),
                'isActive'     => $request->input('isActive')
            ]);
        } else {
            $user->update([
                'firstname'      => $request->input('firstname'),
                'lastname'      => $request->input('lastname'),
                'email'     => $request->input('email'),
                'isActive'     => $request->input('isActive'),
                'password'  => bcrypt($request->input('password'))
            ]);
        }
 
        // $selectedRoles = collect($request->input('role'));

        // Check if any of the selected roles match developer, senior developer, or tech lead
        // if ($selectedRoles->contains('Developer') || $selectedRoles->contains('Senior Developer') || $selectedRoles->contains('Tech Lead')) {
        //     // Convert selected skills to JSON
        //     $skills = json_encode($request->skills);

        //     // Retrieve or create the user skill record
        //     $userSkill = UserSkill::firstOrNew(['user_id' => $user->id]);

        //     $userSkill->technologies = $skills;
        //     $userSkill->save();

        // }

        //assign role
        $user->syncRoles($request->input('role'));

        if($user){
            //redirect dengan pesan sukses
            return redirect()->route('users.index')->with(['success' => 'Data Updated!']);
        }else{
            //redirect dengan pesan error
            return redirect()->route('users.index')->with(['error' => 'Failed!']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);
         $user->update(['isActive' => 0]);

        if ($user->wasChanged('isActive')) {
            return response()->json(['status' => 'success']);
        } else {
            return response()->json(['status' => 'error']);
        }
    }

}
