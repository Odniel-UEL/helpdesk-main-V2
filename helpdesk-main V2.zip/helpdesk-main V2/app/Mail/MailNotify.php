<?php

namespace App\Mail;

use App\Models\Ticket;
use App\Models\User;
use App\Models\Customer;
use App\Models\Sla;
use App\Models\Project;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class MailNotify extends Mailable
{
    use Queueable, SerializesModels;

    public $ticket;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Ticket $ticket, Customer $customer, Sla $sla, Project $project, ?User $user)
    {
        $this->ticket = $ticket;
        $this->customer = $customer;
        $this->sla = $sla;
        $this->project = $project;
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $subject = $this->ticket->number . ' was created (for ' . $this->customer->firstname.' '.$this->customer->lastname. ')';
        // Check if the user is not null
        if (!is_null($this->user)) {
            // If the user is not null, append additional information to the subject
            $subject = $this->ticket->number . ' was assigned to you (for ' . $this->customer->firstname.' '.$this->customer->lastname. ')';
        }
        return $this->view('emails.notify')
                    ->subject($subject)
                    ->with([
                        'ticket' => $this->ticket,
                        'customer' => $this->customer,
                        'sla' => $this->sla,
                        'project' => $this->project,
                        'user' => $this->user,
                    ]);
    }
}
