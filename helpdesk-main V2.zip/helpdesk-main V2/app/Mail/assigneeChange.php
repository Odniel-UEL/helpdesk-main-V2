<?php

namespace App\Mail;

use App\Models\Ticket;
use App\Models\User;
use App\Models\Customer;
use App\Models\Sla;
use App\Models\Project;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;


class assigneeChange extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Ticket $ticket, User $user, Customer $customer, Sla $sla, Project $project)
    {
        $this->ticket = $ticket;
        $this->user = $user;
        $this->customer = $customer;
        $this->sla = $sla;
        $this->project = $project;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.assigneeChange')
                    ->subject($this->ticket->number.' was re-assigned to you (for '.$this->customer->firstname.' '.$this->customer->lastname.')')
                    ->with([
                        'ticket' => $this->ticket,
                        'customer' => $this->customer,
                        'sla' => $this->sla,
                        'project' => $this->project,
                    ]);
    }
}
