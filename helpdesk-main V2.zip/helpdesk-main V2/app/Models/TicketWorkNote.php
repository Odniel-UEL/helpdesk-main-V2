<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TicketWorkNote extends Model
{
    use HasFactory;
    protected $table = 'ticket_worknotes';
    protected $fillable = [
        'ticket_id', 'work_notes','customer_comments', 'user_id'
    ];

    public function ticket()
    {
        return $this->belongsTo(Ticket::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
