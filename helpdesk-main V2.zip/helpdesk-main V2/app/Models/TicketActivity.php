<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TicketActivity extends Model
{
    use HasFactory;
    protected $table = 'ticket_activities';
    protected $fillable = [
        'ticket_id', 'activity_data', 'user_id'
    ];

    protected $casts = [
        'activity_data' => 'array',
    ];

    public function ticket()
    {
        return $this->belongsTo(Ticket::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
