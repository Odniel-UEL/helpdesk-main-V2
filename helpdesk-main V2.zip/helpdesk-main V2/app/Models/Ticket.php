<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'resolutiondate' => 'datetime',
    ];


    public function sla()
    {
        return $this->belongsTo(Sla::class);
    }

    public function emails()
    {
        return $this->hasMany(Log_email::class);
    }

    public function users()
    {
        return $this->belongsTo(User::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    public function assigneeUser()
    {
        return $this->belongsTo(User::class, 'assignee');
    }

    public function openedBy()
    {
        return $this->belongsTo(User::class, 'openedby');
    }

}
