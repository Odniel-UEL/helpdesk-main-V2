<?php

namespace App\Services;

use DateTime;
use DateInterval;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Ticket;
use Illuminate\Support\Facades\DB;


class ReportService {

    private $year, $month, $id;

    public function __construct(int $year, int $month, int $id = null)
    {
        $this->year = $year;
        $this->month = $month;
        $this->id = $id;
    }

    public function getMonthlyTickets()
    {
        $monthlyTickets = Ticket::whereYear('created_at', $this->year)
                                ->whereMonth('created_at', $this->month)
                                ->when(!is_null($this->id), function($monthlyTickets){
                                    $monthlyTickets = $monthlyTickets->whereYear('created_at', $this->year)
                                    ->whereMonth('created_at', $this->month)
                                    ->where('assignee', $this->id);
                                })->count(); 
        return $monthlyTickets;   
    }

    public function getMonthlyDoneTickets()
    {
        $monthlyDoneTickets = Ticket::whereYear('created_at', $this->year)
                                ->whereMonth('created_at', $this->month)
                                ->Where('status', 'Closed')
                                ->when(!is_null($this->id), function($monthlyDoneTickets){
                                    $monthlyDoneTickets = $monthlyDoneTickets
                                    ->whereYear('created_at', $this->year)
                                    ->whereMonth('created_at', $this->month)
                                    ->Where('status', 'Closed')
                                    ->where('assignee', $this->id);
                                })->count(); 
        return $monthlyDoneTickets;   
    }

    public function getMonthlyPendingTickets()
    {
        $monthlyPendingTickets = Ticket::whereYear('created_at', $this->year)
                                ->whereMonth('created_at', $this->month)
                                ->where(function ($query) {
                                    $query->where('status', 'Assigned')
                                        ->orWhere('status', 'To be Deployed')
                                        ->orWhere('status', 'To be Tested');
                                })
                                ->when(!is_null($this->id), function($query) {
                                    $query->where('assignee', $this->id);
                                })
                                ->count(); 
        return $monthlyPendingTickets;   
    }


    public function getOverdueTickets(String $code = null)
    {
        // $assignedTickets = Ticket::with('sla:id,resolution,warning')
        //                         ->whereYear('created_at', $this->year)
        //                         ->whereMonth('created_at', $this->month)
        //                         ->when(!is_null($this->id), function ($query) {
        //                             $query->where('assignee', $this->id);
        //                         })
        //                         ->get();
        $assignedTickets = Ticket::with('sla:id')
                            ->whereYear('created_at', $this->year)
                            ->whereMonth('created_at', $this->month)
                            ->where(function ($query) {
                                $query->where('status', 'Assigned')
                                    ->orWhere('status', 'To be Deployed')
                                    ->orWhere('status', 'To be Tested');
                            })
                            ->when(!is_null($this->id), function ($query) {
                                $query->where('assignee', $this->id);
                            })
                            ->select('tickets.*', 'tickets.resolutionHours as resolution', DB::raw('resolutionHours * 0.75 as warning'))
                            ->get();
        $assigned_plus = 0;

        if ($code == 'red') {
            foreach ($assignedTickets as $ticket) {
                // Convert the string to a Carbon object
                $resolutionDate = Carbon::parse($ticket->resolutiondate);
                // Check if the resolution date is less than the current date
                if ($resolutionDate != null && $resolutionDate->lt(now())) {
                    $assigned_plus += 1;
                }
            }
        }             
        elseif ($code == 'yellow') {
            foreach ($assignedTickets as $ticket) {
                if (!is_null($ticket->resolutiondate)) {
                    $time = Carbon::parse($ticket->created_at);
                    // Calculate the time difference between resolution time and created time
                    $timeDifference = $ticket->resolutiondate->diffInHours($time);
                    // Check if $timeDifference is greater than 0 before further calculations
                    if ($timeDifference > 0) {
                        // Calculate the midpoint time
                        $warningTime = $time->copy()->addHours($timeDifference / 2);
                        // Check if current time is greater than warning time and less than or equal to resolution date
                        if (now()->gt($warningTime) && now()->lte($ticket->resolutiondate)) {
                            $assigned_plus += 1;
                        }
                    }
                }
            }
        }
        
        return $assigned_plus;
    }


    public function getAllDeveloperTickets(){
        $roles = ['Developer', 'Senior Developer'];
        $developers = User::role($roles)->get();
        $allReport = collect([]);
        $combined = [];
        foreach($developers as $developer){
            $report = new ReportService(now()->format('Y'), now()->format('m'), $developer->id);
            $combined = $allReport->push(['name' => $developer->firstname.' '.$developer->lastname, 
                                        'assigned' => $report->getMonthlyTickets(), 
                                        'expired' => $report->getOverdueTickets('red'), 
                                        'warning' => $report->getOverdueTickets('yellow'), 
                                        'pending' => $report->getMonthlyPendingTickets(), 
                                        'done' => $report->getMonthlyDoneTickets()]);
        }
        return $combined;
    }
}


