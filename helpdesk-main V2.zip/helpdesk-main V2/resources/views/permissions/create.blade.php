@extends('layouts.app')

@section('content')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>CREATE PROJECT</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-bell"></i> CREATE PROJECT</h4>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('permissions.store') }}" method="POST">
                            @csrf

                            <div class="form-group">
                                <label>PERMISSION NAME</label>
                                <input type="text" name="name" value="{{ old('name') }}" required placeholder="Enter permission name" class="form-control @error('name') is-invalid @enderror">

                                @error('name')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <input type="textarea" name="description" value="{{ old('description') }}" required placeholder="Enter description name" class="form-control @error('description') is-invalid @enderror">

                                @error('description')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>


                            <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i> SAVE</button>
                            <button class="btn btn-warning btn-reset" type="reset"><i class="fa fa-redo"></i> RESET</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='{{ url()->previous() }}'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@stop