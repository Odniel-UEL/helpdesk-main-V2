@extends('layouts.app')

@section('content')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Edit SLA</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-bell"></i> Edit SLA</h4>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('slas.update', $sla->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="form-group">
                                <label>SLA TITLE</label>
                                <input type="text" name="name" value="{{ old('name', $sla->name) }}" placeholder="Enter the SLA title" class="form-control @error('name') is-invalid @enderror">

                                @error('name')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>RESPONSE TIME</label>
                                <input type="number" name="response" value="{{ old('response', $sla->response) }}" placeholder="Enter the response time" class="form-control @error('response') is-invalid @enderror">

                                @error('response')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>RESOLUTION TIME</label>
                                <input type="number" name="resolution" value="{{ old('resolution', $sla->resolution) }}" placeholder="Enter the resolution time" class="form-control @error('resolution') is-invalid @enderror">

                                @error('resolution')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>WARNING TIME</label>
                                <input type="number" name="warning" value="{{ old('warning', $sla->warning) }}" placeholder="Enter the warning time" class="form-control @error('warning') is-invalid @enderror">

                                @error('warning')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>


                            <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i> SAVE</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='{{ url()->previous() }}'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@stop