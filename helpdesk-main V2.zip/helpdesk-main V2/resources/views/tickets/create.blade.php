@extends('layouts.app')

@section('content')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>New Ticket</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-folder"></i> Create ticket</h4>
                    </div>

                    <div class="card-body">

                        <form action="{{ route('tickets.store') }}" method="POST" enctype="multipart/form-data"
                            class="form-horizontal">
                            {{ csrf_field() }}
                            <div class="form-group">

                                @unless (Auth::user()->hasRole('Customer'))
                                    <div class="form-group">
                                        <label>CUSTOMER</label>
                                        <select
                                            class="form-control select-customer @error('updated_customer') is-invalid @enderror"
                                            name="updated_customer">
                                            <option value="">- SELECT CUSTOMER -</option>
                                            @foreach ($customers as $customer)
                                                <option value="{{ $customer->id }}">{{ $customer->firstname }}
                                                    {{ $customer->lastname }}</option>
                                            @endforeach
                                        </select>
                                        @error('updated_customer')
                                            <div class="invalid-feedback" style="display: block">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                @endunless

                                <div class="form-group">
                                    <label>TICKET NO</label>
                                    <input type="text" name="ticket_no" value="{{ $ticketNo }}" class="form-control"
                                        readonly>
                                </div>

                                <div class="form-group">
                                    <label>PROBLEM SUMMARY</label>
                                    <input type="text" name="problemsummary" value="{{ old('problemsummary') }}"
                                        class="form-control">

                                    @error('problemsummary')
                                        <div class="invalid-feedback" style="display: block">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label>PROBLEM DETAIL</label>
                                    <textarea name="problemdetail" cols="30" rows="30" class="form-control">{{ old('problemdetail') }}</textarea>
                                    @error('problemdetail')
                                        <div class="invalid-feedback" style="display: block">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label>PRIORITY</label>
                                    <select class="form-control select-sla @error('sla_id') is-invalid @enderror"
                                        name="sla_id">
                                        <option value="">- SELECT SLA -</option>
                                        @foreach ($slas as $sla)
                                            <option value="{{ $sla->id }}">{{ $sla->name }}</option>
                                        @endforeach
                                    </select>
                                    @error('sla_id')
                                        <div class="invalid-feedback" style="display: block">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                {{-- @unless (Auth::user()->hasRole('Customer'))
                                        <div class="form-group">
                                            <label>ASSIGN TO</label>
                                            <select class="form-control select-developer @error('assignee') is-invalid @enderror" name="assignee">
                                                <option value="">- Choose a Assignee -</option>
                                                @foreach ($users as $user)
                                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                                @endforeach
                                            </select>
                                            @error('assignee')
                                            <div class="invalid-feedback" style="display: block">
                                                {{ $message }}
                                            </div>
                                            @enderror
                                        </div>
                                    @endunless --}}


                                <button class="btn btn-primary mr-1 btn-submit" type="submit"><i
                                        class="fa fa-paper-plane"></i> SAVE</button>
                                <button class="btn btn-warning btn-reset" type="reset"><i class="fa fa-redo"></i>
                                    RESET</button>
                                <button class="btn btn-secondary btn-cancel" type="button"
                                    onclick="window.location='{{ url()->previous() }}'">
                                    <i class="fa fa-times"></i> CANCEL
                                </button>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
    </div>
    </section>
    </div>
@stop

<script>
    document.querySelector('.btn-reset').addEventListener('click', function() {
        // Ensure all fields are cleared
        document.querySelector('.form-horizontal').reset();
    });
    window.addEventListener('customer-updated', event => {
        document.getElementById('updated_customer').value = event.detail.selectedCustomer;
    })
</script>
