
@extends('layouts.app')

@section('content')
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Ticket</h1>
        </div>

        <div class="section-body">

            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-clipboard-list"></i> Tickets</h4>
                </div>

                <div class="card-body">
                    <form action="" id="search-form" method="GET">
                        <div class="form-group">
                            <div class="input-group mb-3">
                                @can('tickets.create')
                                    <div class="input-group-prepend">
                                        <a href="{{ route('tickets.create') }}" class="btn btn-primary" style="padding-top: 10px;"><i class="fa fa-plus-circle"></i> CREATE</a>
                                    </div>
                                @endcan
                                {{-- <input type="text" class="form-control" name="q"
                                       placeholder="Search based on problems">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> SEARCH
                                    </button>
                                </div> --}}
                                <input type="text" class="form-control" name="q" id="search-input"
                                       placeholder="Search based on problems" value="{{ old('q') }}">
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th scope="col" style="text-align: center;">ID.</th>
                                <th scope="col">NUMBER</th>
                                <th scope="col">URGENCY</th>
                                <th scope="col">CUSTOMER</th>
                                <th scope="col">CREATED</th>
                                <th scope="col">PROJECT</th>
                                <th scope="col">PROBLEM</th>
                                <th scope="col">ASSIGNEE</th>
                                <th scope="col">STATUS</th>
                                <th scope="col" style="width: 15%;text-align: center">ACTION</th>
                            </tr>
                            </thead>
                            <tbody id="tickets-table">
                            
                            </tbody>
                        </table>
                        <div style="text-align: center">
                            {{$tickets->links("vendor.pagination.bootstrap-4")}}
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
</div>

<script>
    $(document).ready(function() {
        // Initial load of user scores
        updateTickets('');

        // Listen for form submit
        $('#search-input').on('input', function(event) {
            // event.preventDefault();
            var query = $('#search-input').val();
            updateTickets(query);
        });

        function getStatusClass(status) {
            var heightStyle = 'style="height: 20px; margin-top:2em"';
            switch (status) {
                case 'New':
                    return 'badge badge-primary"'+ heightStyle;;
                case 'Assigned':
                    return 'badge badge-warning"'+ heightStyle;;
                case 'To be Deployed':
                    return 'badge badge-secondary"'+ heightStyle;;
                case 'Closed':
                    return 'badge badge-success"'+ heightStyle;;
                case 'Cancelled':
                    return 'badge badge-danger"'+ heightStyle;;
                default:
                    return 'badge badge-secondary"'+ heightStyle;;
            }
        }

        // Function to update tickets based on query
        function updateTickets(query) {
            var ticketsData = [
                @foreach ($tickets as $ticket)
                {   
                    id: {{ $ticket->id }}, 
                    number: '{{ $ticket->number }}', 
                    sla: '{{ $ticket->sla->name }}',
                    customer: '{{ $ticket->customer->firstname }} {{ $ticket->customer->lastname }}',
                    createdat: '{{ Carbon\Carbon::parse($ticket->created_at)->format('d M Y - H:i') }}',
                    project: '{{ $ticket->project->name }}',
                    problemSummary: '{{ $ticket->problemsummary }}',
                    assignee: '{{ optional($ticket->assigneeUser)->firstname }} {{ optional($ticket->assigneeUser)->lastname }}',
                    status: '{{ $ticket->status }}'
                },
                @endforeach
            ];


            var filteredTickets = ticketsData.filter(function(ticket) {
                return ticket.problemSummary.toLowerCase().includes(query.toLowerCase());
            });

            // Update the table with filtered user scores
            var tableBody = $('#tickets-table');
            tableBody.empty(); // Clear existing rows
            filteredTickets.forEach(function(ticket) {
                var row = $('<tr>');
                row.append('<td>' + ticket.id + '</td>');
                row.append('<td>' + ticket.number + '</td>');
                row.append('<td>' + ticket.sla + '</td>');
                row.append('<td>' + ticket.customer + '</td>');
                row.append('<td>' + ticket.createdat + '</td>');
                row.append('<td>' + ticket.project + '</td>');
                row.append('<td>' + ticket.problemSummary + '</td>');
                row.append('<td>' + ticket.assignee + '</td>');
                // row.append('<td class="' + getStatusClass(ticket.status) + '">' + ticket.status + '</td>');
                row.append('<td>' + ticket.status + '</td>');


                row.append('<td class="text-center">' +
                                @can('tickets.edit')
                                    '<a href="{{ url("tickets") }}/' + ticket.id + '/edit" class="btn btn-sm btn-primary">' +
                                        '<i class="fa fa-pencil-alt"></i>' +
                                    '</a>' +
                                @endcan
                            '</td>');
                tableBody.append(row);
            });
        }
    });
</script>

<script>
    //ajax delete
    function Delete(id)
        {
            var id = id;
            var token = $("meta[name='csrf-token']").attr("content");

            swal({
                title: "ARE YOU SURE ?",
                text: "Do you want to delete this data!",
                icon: "warning",
                buttons: [
                    'NO',
                    'YES'
                ],
                dangerMode: true,
            }).then(function(isConfirm) {
                if (isConfirm) {


                    //ajax delete
                    jQuery.ajax({
                        url: "{{ route("tickets.index") }}/"+id,
                        data:     {
                            "id": id,
                            "_token": token
                        },
                        type: 'DELETE',
                        success: function (response) {
                            if (response.status == "success") {
                                swal({
                                    title: 'SUCCEED!',
                                    text: 'The data was successfully deleted!',
                                    icon: 'success',
                                    timer: 1000,
                                    showConfirmButton: false,
                                    showCancelButton: false,
                                    buttons: false,
                                }).then(function() {
                                    location.reload();
                                });
                            }else{
                                swal({
                                    title: 'FAIL!',
                                    text: 'Data failed to be deleted!',
                                    icon: 'error',
                                    timer: 1000,
                                    showConfirmButton: false,
                                    showCancelButton: false,
                                    buttons: false,
                                }).then(function() {
                                    location.reload();
                                });
                            }
                        }
                    });

                } else {
                    return true;
                }
            })
        }
</script>
@stop