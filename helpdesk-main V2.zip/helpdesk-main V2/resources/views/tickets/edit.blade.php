@extends('layouts.app')

@push('styles')
    <link href="css/public/assets/css/EditTicketStyles.css.css" rel="stylesheet">
@endpush

@section('content')
    <style>
        /*
            .incident-container {
              max-width: 800px;
              margin: 50px auto;
              padding: 20px;
              border: 1px solid #ccc;
              border-radius: 5px;
              box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            } */

        h1,
        h2 {
            text-align: center;
        }

        .form-container {
            display: flex;
            justify-content: space-between;
        }

        .form-column {
            flex: 1;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: calc(100% - 2px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .divider {
            border-top: 2px solid #ccc;
            margin: 20px 0;
        }

        .activities-container {
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        .notes-container {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
        }

        .notes-container .form-group {
            margin-bottom: 10px;
        }

        /* Styles for activities */
        .activity-box {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .activity-box p {
            margin: 0;
        }

        .activity-box span {
            font-size: 0.8em;
            color: #777;
        }

        .activity-box {
            position: relative;
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
        }

        .activity-timestamp {
            position: absolute;
            top: 5;
            right: 5;
            font-size: 13px !important;
            color: #999;
        }

        .activity-author {

            font-size: 13px !important;
            color: #999;
        }

        .activity-details {

            margin: 10 0 0 40
        }


        #suggestions {
            position: absolute;
            top: 100%;
            z-index: 1000;
            width: 90%;
            max-height: 200px;
            overflow-y: auto;
            background-color: #fff;
            border: 1px solid #ccc;
            border-top: none;
            border-radius: 0 0 5px 5px;
        }

        .user-suggestion {
            padding: 8px 12px;
            cursor: pointer;
        }

        .user-suggestion:hover {
            background-color: #f0f0f0;
        }
    </style>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Edit Tiket</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-folder"></i> Edit tiket</h4>
                    </div>

                    <div class="card-body">

                        <form action="{{ route('tickets.update', $ticket->id) }}" method="POST"
                            enctype="multipart/form-data" class="form-horizontal">
                            @csrf
                            @method('PUT')

                            @if ($ticket->status != 'Closed' && $ticket->status != 'Cancelled')
                                <div class="mb-5 d-flex justify-content-end">
                                    <button class="btn btn-primary mr-1 btn-submit" type="submit"><i
                                            class="fa fa-paper-plane"></i> SAVE</button>
                                    <button class="btn btn-secondary btn-cancel" type="button"
                                        onclick="window.location='{{ url()->previous() }}'">
                                        <i class="fa fa-times"></i> CANCEL
                                    </button>
                                </div>
                            @endif
                            <div class="incident-container">
                                <div class="form-container">
                                    <div class="row col-12">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="incident-number" class="col-sm-4 col-form-label">Number:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="ticket_no"
                                                        value="{{ old('ticket_no', $ticket->number) }}" class="form-control"
                                                        readonly />
                                                </div>
                                            </div>

                                            <input type="hidden" name="updated_customer" id="updated_customer"
                                                value="{{ $ticket->customer_id }}">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Caller</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="customer"
                                                        value="{{ $ticket->customer->firstname }} {{ $ticket->customer->lastname }}"
                                                        class="form-control" readonly>
                                                </div>

                                            </div>

                                            <div class="form-group row" style="display: none">
                                                <label for="openedBy" class="col-sm-4 col-form-label">Opened By:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="openedBy"
                                                        value="{{ old('openedby', $ticket->openedBy->firstname) }}"
                                                        class="form-control" readonly />
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="priority" class="col-sm-4 col-form-label">Priority:</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control select-sla" name="sla_id">
                                                        <option disabled value="">- SELECT SLA -</option>
                                                        @foreach ($slas as $sla)
                                                            @if ($ticket->sla_id == $sla->id)
                                                                <option value="{{ $sla->id }}" selected>
                                                                    {{ $sla->name }}</option>
                                                            @else
                                                                <option value="{{ $sla->id }}">{{ $sla->name }}
                                                                </option>
                                                            @endif
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>

                                            @hasanyrole('Admin|Tech Lead|Developer|Senior Developer')
                                                <div class="form-group row">
                                                    <label for="resolutionHours" class="col-sm-4 col-form-label">Resolution
                                                        Hours:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="resolutionHours"
                                                            value="{{ old('resolutionHours', $ticket->resolutionHours) }}"
                                                            class="form-control @error('resolutionHours') is-invalid @enderror" />

                                                        @error('resolutionHours')
                                                            <div class="invalid-feedback" style="display: block">
                                                                {{ $message }}
                                                            </div>
                                                        @enderror
                                                    </div>
                                                </div>
                                            @endhasanyrole
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="state" class="col-sm-4 col-form-label">State:</label>
                                                <div class="col-sm-8">
                                                    <select name="status" id="status"
                                                        class="form-control select-status @error('status') is-invalid @enderror">
                                                        <option disabled value="">-- Change status --</option>
                                                        <option value="New"
                                                            @if ($ticket->status == 'New') selected @endif>New</option>
                                                        <option value="Assigned"
                                                            @if ($ticket->status == 'Assigned') selected @endif>Assigned
                                                        </option>
                                                        <option value="To be Tested"
                                                            @if ($ticket->status == 'To be Tested') selected @endif>To be Tested
                                                        </option>
                                                        <option value="To be Deployed"
                                                            @if ($ticket->status == 'To be Deployed') selected @endif>To be Deployed
                                                        </option>
                                                        <option value="Closed"
                                                            @if ($ticket->status == 'Closed') selected @endif>Closed
                                                        </option>
                                                        <option value="Cancelled"
                                                            @if ($ticket->status == 'Cancelled') selected @endif>Cancelled
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="project" class="col-sm-4 col-form-label">Project:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="project"
                                                        value="{{ old('project', $ticket->project->name) }}"
                                                        class="form-control" readonly />
                                                </div>
                                            </div>
                                            {{-- <div class="form-group row">
                                                <label for="assigned-to" class="col-sm-4 col-form-label">Assigned to:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" id="assignee" name="assignee" class="form-control @error('assignee') is-invalid @enderror" />                                                    
                                                    @error('assignee')
                                                    <div class="invalid-feedback" style="display: block">
                                                        {{ $message }}
                                                    </div>
                                                    @enderror
                                                    <div id="suggestions"></div>
                                                </div>
                                            </div> --}}

                                            <div class="form-group row">
                                                <label for="createdAt" class="col-sm-4 col-form-label">Created:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="createdAt"
                                                        value="{{ old('created_at', $ticket->created_at) }}"
                                                        class="form-control" readonly />
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                </div>

                                <div class="description-container col-12 mt-5">
                                    <div class="form-group row">
                                        <label for="problemsummary" class="col-sm-2 col-form-label">Short
                                            Description:</label>
                                        <div class="col-sm-10">
                                            <input type="text"name="problemsummary"
                                                value="{{ old('problemsummary', $ticket->problemsummary) }}"
                                                class="form-control @error('problemsummary') is-invalid @enderror"
                                                @hasrole('Developer') readonly @endhasrole />

                                            @error('problemsummary')
                                                <div class="invalid-feedback" style="display: block">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="problemdetail" class="col-sm-2 col-form-label">Description:</label>
                                        <div class="col-sm-10">
                                            <textarea id="problemdetail" rows="4" name="problemdetail" @hasrole('Developer') readonly @endhasrole>{{ old('problemdetail', $ticket->problemdetail) }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="notes-container">
                                    <div class="form-group">
                                        <label for="work-notes">Work notes:</label>
                                        <textarea id="worknotes" name="worknotes" rows="3"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="customer-comments">Customer comments:</label>
                                        <textarea id="customer_comments" name="customer_comments" rows="3"></textarea>
                                    </div>
                                </div>

                            </div>
                            {{-- ----------------------------------------- --}}
                            {{-- <div class="form-group">
                                    

                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>TICKET NO</label>
                                                <input type="text" name="ticket_no" value="{{ old('ticket_no', $ticket->number) }}" class="form-control" readonly>
                                            </div>
        
                                            <div class="form-group">
                                                <label>PROJECT</label>
                                                <select class="form-control select-project @error('project') is-invalid @enderror" name="project">
                                                    <option value="">- SELECT PROJECT -</option>
                                                    @foreach ($projects as $project)
                                                        @if ($ticket->project_id == $project->id)
                                                            <option value="{{ $project->id }}" selected>{{ $project->name }}</option>
                                                        @else
                                                            <option value="{{ $project->id }}">{{ $project->name }}</option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                                @error('project')
                                                <div class="invalid-feedback" style="display: block">
                                                    {{ $message }}
                                                </div>
                                                @enderror
                                            </div>

                                            <div class="form-group">
                                                <label>URGENCY / SLA</label>
                                                <select class="form-control select-sla @error('sla_id') is-invalid @enderror" name="sla_id">
                                                    <option value="">- SELECT SLA -</option>
                                                    @foreach ($slas as $sla)
                                                        @if ($ticket->sla_id == $sla->id)
                                                            <option value="{{ $sla->id }}" selected>{{ $sla->name }}</option>
                                                        @else
                                                            <option value="{{ $sla->id }}">{{ $sla->name }}</option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                                @error('sla_id')
                                                <div class="invalid-feedback" style="display: block">
                                                    {{ $message }}
                                                </div>
                                                @enderror
                                            </div>

                                            <div class="form-group">
                                                <label>ASSIGN TO</label>
                                                
                                                <input type="hidden" name="assignee" value="{{ old('assignee', $ticket->assignee) }}" class="form-control">
                                                <input type="text" name="assigneeName" value="{{ optional($ticket->assigneeUser)->name }}" class="form-control" readonly>
                                                
                                                @hasrole('Tech Lead')
                                                <br/>
                                                <select class="form-control select-developer @error('assignee') is-invalid @enderror" name="assignee">
                                                    <option value="">- Select Developer -</option>
                                                    @foreach ($users as $user)
                                                        @if ($ticket->assignee == $user->id)
                                                            <option value="{{ $user->id }}" selected>{{ $user->name }}</option>
                                                        @else
                                                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                                                        @endif
                                                    
                                                    @endforeach
                                                </select>
                                                @error('assignee')
                                                <div class="invalid-feedback" style="display: block">
                                                    {{ $message }}
                                                </div>
                                                @enderror
                                                @endhasrole
                                            </div>
                                        </div>
    
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>PROBLEM SUMMARY</label>
                                                <input type="text" name="summary" value="{{ old('summary', $ticket->problemsummary) }}" class="form-control" @hasrole('Developer') readonly @endhasrole >
        
                                                @error('summary')
                                                <div class="invalid-feedback" style="display: block">
                                                    {{ $message }}
                                                </div>
                                                @enderror
                                            </div>
        
                                            <div class="form-group">
                                                <label>PROBLEM DETAIL</label>
                                                <textarea  cols="30" rows="30" class="form-control"  name="detail" @hasrole('Developer') readonly @endhasrole>{{ old('detail', $ticket->problemdetail) }}</textarea>
                                                @error('detail')
                                                <div class="invalid-feedback" style="display: block">
                                                    {{ $message }}
                                                </div>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label>CHANGE STATUS</label>
                                                <select name="status" id="status" class="form-control select-status @error('status') is-invalid @enderror" >
                                                    <option value="">-- Change status --</option>
                                                    <option value="Assigned" @if ($ticket->status == 'Assigned') selected @endif>Assigned</option>
                                                    @hasanyrole('Admin|Tech Lead|Developer|Senior Developer')
                                                    <option value="To be Deployed" @if ($ticket->status == 'To be Deployed') selected @endif>To be Deployed</option>
                                                    <option value="Closed" @if ($ticket->status == 'Closed') selected @endif>Closed</option>
                                                    @endhasanyrole
                                                    <option value="Cancelled" @if ($ticket->status == 'Cancelled') selected @endif>Cancelled</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>RESOLUTION DATE</label>
                                                <input type="text" name="resolution" value="{{ old('summary', $ticket->resolutiontime) }}" class="form-control" readonly>                                                    
                                            </div>

                                            @php
                                                // Calculate remaining time only if the ticket status is not "Closed"
                                                if ($ticket->status != 'Closed' && $ticket->status != 'Cancelled') {
                                                    $now = now();
                                                    $resolutionTime = Carbon\Carbon::parse($ticket->resolutiontime);
                                                    $timeDifference = $now->diffInHours($resolutionTime);

                                                    $createdAt = Carbon\Carbon::parse($ticket->created_at);
                                                    $resolutionEndTime = Carbon\Carbon::parse($ticket->resolutiontime);

                                                    // Calculate total resolution hours
                                                    $totalHours = max(1, $createdAt->diffInHours($resolutionEndTime));

                                                    // Calculate progress percentage within the range of 0 to 100
                                                    $progressPercentage = min(100, ($totalHours - $timeDifference) / $totalHours * 100);
                                                } else {
                                                    // If the ticket is closed, use the existing progress percentage
                                                    $progressPercentage = $ticket->progress_percentage;
                                                }

                                                $progressColorClass = '';
                                                if ($progressPercentage < 50 && $progressPercentage > 0) {
                                                    $progressColorClass = 'bg-success';
                                                } elseif ($progressPercentage < 75 && $progressPercentage >= 50) {
                                                    $progressColorClass = 'bg-warning';
                                                } elseif ($progressPercentage >= 75) {
                                                    $progressColorClass = 'bg-danger';
                                                } else {
                                                    $progressColorClass = 'bg-danger';
                                                }
                                            @endphp

                                            <div class="progress">
                                                <div class="progress-bar {{ $progressColorClass }}" role="progressbar" style="width: {{ round($progressPercentage) }}%" aria-valuenow="{{ round($progressPercentage) }}" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>

                                            <div>
                                                <input type="hidden" name="progressPercentage" value="{{ round($progressPercentage) }}" class="form-control" >
                                                {{ round($progressPercentage) }}%
                                            </div>

                                            
                                        </div>
                                    </div>
                                    
                                </div> --}}

                        </form>
                        <div class="activities-container" id="activities-container">
                            @foreach ($activities as $activity)
                                <div class="activity-box">
                                    <span class="activity-author">{{ $activity->user->firstname }}
                                        {{ $activity->user->lastname }}</span>
                                    @if ($activity instanceof \App\Models\TicketActivity)
                                        <div class="activity-details">
                                            @foreach ($activity->activity_data as $key => $value)
                                                @if (!empty($value))
                                                    @if ($key === 'Created')
                                                        <div class="activity-item"><b>{{ $key }}:
                                                                &nbsp;&nbsp;</b>{{ \Carbon\Carbon::parse($value)->toDateTimeString() }}
                                                        </div>
                                                    @else
                                                        <div class="activity-item"><b>{{ $key }}:
                                                                &nbsp;&nbsp;</b>{{ $value }}</div>
                                                    @endif
                                                @endif
                                            @endforeach
                                        </div>
                                    @elseif ($activity instanceof \App\Models\TicketWorkNote)
                                        <div class="activity-details">
                                            @if (!empty($activity->work_notes))
                                                <div class="activity-item"><b>Work Notes:
                                                        &nbsp;&nbsp;</b>{{ $activity->work_notes }}</div>
                                            @endif
                                            @if (!empty($activity->customer_comments))
                                                <div class="activity-item"><b>Customer Comments:
                                                        &nbsp;&nbsp;</b>{{ $activity->customer_comments }}</div>
                                            @endif
                                        </div>

                                        <span class="activity-timestamp">Notes. {{ $activity->created_at }}</span>
                                    @endif
                                </div>
                            @endforeach
                        </div>



                    </div>
                </div>
            </div>
        </section>
    </div>


@stop

<script>
    window.addEventListener('customer-updated', event => {
        document.getElementById('updated_customer').value = event.detail.selectedCustomer;
    })
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Function to show suggestions
        function showSuggestions(query) {
            $.ajax({
                url: "{{ route('get.users') }}",
                method: 'GET',
                data: {
                    query: query
                },
                success: function(data) {
                    $('#suggestions').empty();
                    data.forEach(function(user) {
                        $('#suggestions').append('<div class="user-suggestion">' + user +
                            '</div>');
                    });
                    $('#suggestions').show(); // Show suggestions
                }
            });
        }

        // Function to hide suggestions
        function hideSuggestions() {
            $('#suggestions').empty().hide();
        }

        // Input event handling for assignee input
        $('#assignee').on('input', function() {
            var query = $(this).val();
            if (query.trim() === '') {
                hideSuggestions();
            } else {
                showSuggestions(query);
            }
        });

        // Click event handling for user suggestions
        $(document).on('click', '.user-suggestion', function() {
            var selectedUser = $(this).text();
            $('#assignee').val(selectedUser);
            hideSuggestions(); // Hide suggestions after selection
        });

        // Focus event handling for assignee input (to show suggestions)
        $('#assignee').on('focus', function() {
            var query = $(this).val();
            if (query.trim() !== '') {
                showSuggestions(query);
            }
        });

        // Click event handling for the document body
        $(document).on('click', function(event) {
            // Check if the clicked element is within the suggestion div or assignee input field
            if (!$(event.target).closest('#suggestions').length && !$(event.target).is('#assignee')) {
                hideSuggestions(); // Hide suggestions if clicked outside
            }
        });
    });
</script>



{{-- <script>
    document.addEventListener("DOMContentLoaded", function () {
      // Function to add activities with date and time
      function addActivity(activity, datetime) {
        const activitiesContainer = document.getElementById(
          "activities-container"
        );

        const activityBox = document.createElement("div");
        activityBox.classList.add("activity-box");

        const activityText = document.createElement("p");
        activityText.textContent = activity;

        const datetimeText = document.createElement("span");
        datetimeText.textContent = datetime.toLocaleString(); // Format date and time

        activityBox.appendChild(activityText);
        activityBox.appendChild(datetimeText);

        activitiesContainer.appendChild(activityBox);
      }

      // Simulated activity data
      const activities = [
        {
          activity: "Assigned to Jane Smith",
          datetime: new Date("2024-04-21T08:30:00"),
        },
        {
          activity: "Updated priority to High",
          datetime: new Date("2024-04-21T10:15:00"),
        },
        {
          activity: "Added notes: Please follow up with customer",
          datetime: new Date("2024-04-21T12:45:00"),
        },
      ];

      // Add activities to the container
      activities.forEach((activity) => {
        addActivity(activity.activity, activity.datetime);
      });

      // Functionality to handle posting notes (you can add this)
      document
        .getElementById("post-button")
        .addEventListener("click", function () {
          const workNotes = document.getElementById("work-notes").value;
          const customerComments =
            document.getElementById("customer-comments").value;

          // Add functionality to post notes here
          // For now, let's just log the notes
          console.log("Work notes:", workNotes);
          console.log("Customer comments:", customerComments);
        });
    });
  </script> --}}
