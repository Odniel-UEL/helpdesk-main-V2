@props([
        'value' => ''
        ])

<option  value="{{ $value }}" >
    {{ $value }}
</option>