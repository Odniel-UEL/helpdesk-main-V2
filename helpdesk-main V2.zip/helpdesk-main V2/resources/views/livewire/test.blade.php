<div>
   <input type="text" wire:model="testmodel">
   {{ $testmodel }}
</div>
