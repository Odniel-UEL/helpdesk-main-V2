<div class="form-group">
    <label>EMAIL</label>
    <input wire:model="email" type="email" placeholder="Enter the email" class="form-control">
    @error('email') 
    <div class="invalid-feedback" style="display: block">
        {{ $message }}
    </div>
    @enderror
</div>
