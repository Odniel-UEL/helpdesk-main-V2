<div class="form-group row">
    <label for="selectedCustomer" class="col-sm-4 col-form-label">Caller</label>
    <div class="col-sm-8">
        <select id="selectedCustomer" wire:model="selectedCustomer" class="form-control">
            <option value="">- SELECT CUSTOMER -</option>
            @foreach ($customers as $item)
                <option value="{{ $item->id }}">{{ $item->name }}</option>
            @endforeach
        </select>
    </div>
</div>