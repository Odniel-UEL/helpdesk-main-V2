@extends('layouts.app')

@section('content')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>CREATE CUSTOMER</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-bell"></i> CREATE CUSTOMER</h4>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('customers.store') }}" method="POST">
                            @csrf

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label>FIRST NAME</label>
                                    <input type="text" name="firstname" value="{{ old('firstname') }}" placeholder="Enter the first name"
                                        class="form-control @error('firstname') is-invalid @enderror">
        
                                    @error('firstname')
                                    <div class="invalid-feedback" style="display: block">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
    
                                <div class="form-group col-md-6">
                                    <label>LAST NAME</label>
                                    <input type="text" name="lastname" value="{{ old('lastname') }}" placeholder="Enter the last name"
                                        class="form-control @error('lastname') is-invalid @enderror">
        
                                    @error('lastname')
                                    <div class="invalid-feedback" style="display: block">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <label>ADDRESS</label>
                                <textarea class="form-control address @error('address') is-invalid @enderror" name="address" placeholder="Enter the address" rows="10">{!! old('address') !!}</textarea>
                                @error('address')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>TELEPHONE</label>
                                <input type="phone" name="phone" value="{{ old('phone') }}" placeholder="Enter the phone number" class="form-control @error('phone') is-invalid @enderror">

                                @error('phone')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>EMAIL</label>
                                <input type="email" id="email" name="email" value="{{ old('email') }}" placeholder="Enter the email address" class="form-control @error('email') is-invalid @enderror">
                                <div id="emailError" class="invalid-feedback" style="display: none">
                                    Invalid email format
                                </div>
                                @error('email')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>PROJECT</label>
                                <select class="form-control select-project @error('project') is-invalid @enderror" name="project">
                                    <option value="">- SELECT PROJECT -</option>
                                    @foreach ($projects as $project)
                                        <option value="{{ $project->id }}">{{ $project->name }}</option>
                                    @endforeach
                                </select>
                                @error('project')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i> SAVE</button>
                            <button class="btn btn-warning btn-reset" type="reset"><i class="fa fa-redo"></i> RESET</button><button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='{{ url()->previous() }}'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>    
        document.querySelector('.btn-reset').addEventListener('click', function() {
            // Ensure all fields are cleared
            document.querySelector('.form-horizontal').reset();
        });
        document.getElementById('email').addEventListener('input', function() {
            var emailInput = this.value.trim();
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
            if (!emailPattern.test(emailInput)) {
                document.getElementById('email').classList.add('is-invalid');
                document.getElementById('emailError').style.display = 'block';
            } else {
                document.getElementById('email').classList.remove('is-invalid');
                document.getElementById('emailError').style.display = 'none';
            }
        });
    </script>
@stop