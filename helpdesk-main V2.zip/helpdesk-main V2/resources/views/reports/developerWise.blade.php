@extends('layouts.app')

@section('content')
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Report</h1>
        </div>

        <div class="section-body">

            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-unlock"></i> Developer Wise Report</h4>
                </div>

                <div class="card-body">
                    <form id="reportForm" class="row">
                        <div class="col-lg-9 row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Date Range:</label>
                                    <input type="text" id="dateRange" class="form-control" name="date_range">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Customer:</label>
                                    <select id="developerSelect" class="form-control" name="developer_id">
                                        <option value="">Select Developer</option>
                                        @foreach($developers as $developer)
                                            <option value="{{ $developer->id }}">{{ $developer->firstname }} {{ $developer->lastname }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>                        
                        <div class="col-lg-3 d-flex align-items-center justify-content-center">
                            <button class="btn btn-primary mr-1 btn-submit" id="generateReport">Generate Report</button>
                        </div>
                    </form>
                    
                    <div class="table-responsive" id="reportTable">
                        <table id="reportDataTable" class="table table-bordered mt-4">
                            <thead>
                                <tr>
                                    <th>Number</th>
                                    <th>Priority</th>
                                    <th>Assigned at</th>
                                    <th>Project</th>
                                    <th>Problem</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Table rows will be inserted here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
    });

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {

        $('#generateReport').click(function(e) {
            e.preventDefault();

            $.ajax({
                url: '{{ route('reports.generateDev') }}',
                method: 'POST',
                data: $('#reportForm').serialize(),
                success: function(response) {
                    console.log('Response:', response); // Debugging line
                    table.clear().draw();
                    if (response.length > 0) {
                        response.forEach(function(ticket) {
                            table.row.add([
                                ticket.number,
                                ticket.sla ? ticket.sla.name : 'N/A',
                                new Date(ticket.assigneddate).toLocaleString(),
                                ticket.project ? ticket.project.name : 'N/A',
                                ticket.problemsummary,
                                ticket.status
                            ]).draw();
                        });
                    } else {
                        table.row.add(['No tickets found for the selected date range.', '', '', '', '', '']).draw();
                    }
                },
                error: function() {
                    table.clear().draw();
                    table.row.add(['An error occurred while generating the report. Please try again.', '', '', '', '', '']).draw();
                }
            });
        });


        var table = $('#reportDataTable').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    text: 'Export PDF',
                    action: function () {
                        var developerName = $('#developerSelect option:selected').text().replace(/\s+/g, '_'); // Replace spaces with underscores
                        var dateRange = $('#dateRange').val().replace(/\s+/g, '_').replace(/:/g, '-'); // Replace spaces with underscores and colon with hyphen

                        var docDefinition = {
                            content: [
                                { text: 'Developer Wise Ticket Report', style: 'header',alignment: 'center' },
                                { text: `Date Range: ${$('#dateRange').val()}`, margin: [0, 10] },
                                { text: `Developer: ${$('#developerSelect option:selected').text()}`, margin: [0, 5] },
                                { text: '', margin: [0, 20] }, // Space between title and table
                                {
                                    table: {
                                        headerRows: 1,
                                        widths: [ '*', '*', '*', '*', '*', '*' ],
                                        body: [
                                            [
                                                { text: 'Number', style: 'tableHeader' },
                                                { text: 'Priority', style: 'tableHeader' },
                                                { text: 'Assigned at', style: 'tableHeader' },
                                                { text: 'Project', style: 'tableHeader' },
                                                { text: 'Problem', style: 'tableHeader' },
                                                { text: 'Status', style: 'tableHeader' }
                                            ],
                                            ...table.rows({ search: 'applied' }).data().toArray().map(row => [
                                                row[0], row[1], row[2], row[3], row[4], row[5]
                                            ])
                                        ]
                                    }
                                }
                            ],
                            styles: {
                                header: {
                                    fontSize: 18,
                                    bold: true
                                },
                                table: {
                                    margin: [0, 10, 0, 15]
                                },
                                tableHeader: {
                                    bold: true,
                                    fontSize: 12,
                                    color: 'black'
                                }
                            }
                        };
                        var fileName = `Developer_Wise_Ticket_Report_${developerName}_${dateRange}.pdf`;
                        pdfMake.createPdf(docDefinition).download(fileName);
                    }
                }
            ],
            "paging": false,
            "info": false,
            "searching": false
        });

        
    });
</script>
@stop
