@extends('layouts.app')

@section('content')
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Edit User</h1>
        </div>

        <div class="section-body">

            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-unlock"></i> Edit User</h4>
                </div>

                <div class="card-body">
                    <form action="{{ route('users.update', $user->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>FIRST NAME</label>
                                <input type="text" name="firstname" value="{{ old('firstname', $user->firstname) }}"
                                    placeholder="Enter the first name"
                                    class="form-control @error('firstname') is-invalid @enderror">
    
                                @error('firstname')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group col-md-6">
                                <label>LAST NAME</label>
                                <input type="text" name="lastname" value="{{ old('lastname', $user->lastname) }}"
                                    placeholder="Enter the last name"
                                    class="form-control @error('lastname') is-invalid @enderror">
    
                                @error('lastname')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group">
                            <label>EMAIL</label>
                            <input type="email" id="email" name="email" value="{{ old('email', $user->email) }}"
                                placeholder="Enter the email" class="form-control @error('email') is-invalid @enderror">
                                <div id="emailError" class="invalid-feedback" style="display: none">
                                    Invalid email format
                                </div>
                            @error('email')
                            <div class="invalid-feedback" style="display: block">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>PASSWORD</label>
                                    <input type="password" name="password" value="{{ old('password') }}"
                                        placeholder="Enter the password"
                                        class="form-control @error('password') is-invalid @enderror">

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>PASSWORD</label>
                                    <input type="password"  id="password_confirmation" name="password_confirmation"
                                        value="{{ old('password_confirmation') }}"
                                        placeholder="Enter the password confirmation" class="form-control">
                                        <div id="passwordConfirmationError" class="invalid-feedback" style="display: none;">
                                            Passwords do not match
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-lg-6">
                                <label class="font-weight-bold">ROLE</label>
                                <br/>
                                    @foreach ($roles as $role)
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input role-checkbox" type="checkbox" name="role[]" value="{{ $role->name }}"
                                                id="check-{{ $role->id }}" {{ $user->roles->contains($role->id) ? 'checked' : '' }}>
                                            <label class="form-check-label" for="check-{{ $role->id }}">
                                                {{ $role->name }}
                                            </label>
                                        </div>
                                        <br/>
                                    @endforeach
                            </div>
    

                            <div class="form-group col-lg-6">
                                <label>CHANGE STATUS</label>
                                <select name="isActive" id="isActive" class="form-control select-status @error('isActive') is-invalid @enderror" >
                                    <option value="">-- Change status --</option>
                                    <option value="1" @if ($user->isActive == "1") selected @endif>Active</option>
                                    <option value="0" @if ($user->isActive == "0") selected @endif>Inactive</option>
                                </select>
                            </div>
                            
                        </div>

                        <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i>
                            UPDATE</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='{{ url()->previous() }}'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    // Get the password and confirm password input fields and the error message div
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('password_confirmation');
    const passwordConfirmationError = document.getElementById('passwordConfirmationError');

    // Add event listener to the confirm password field for input event
    confirmPasswordInput.addEventListener('input', validatePasswordConfirmation);

    // Function to validate password confirmation
    function validatePasswordConfirmation() {
        const password = passwordInput.value.trim(); // Get the trimmed password value
        const confirmPassword = confirmPasswordInput.value.trim(); // Get the trimmed confirm password value

        // Check if password and confirm password match
        if (password === confirmPassword) {
            // Hide the error message if passwords match
            passwordConfirmationError.style.display = 'none';
        } else {
            // Show the error message if passwords don't match
            passwordConfirmationError.style.display = 'block';
        }
    }

    document.getElementById('email').addEventListener('input', function() {
        var emailInput = this.value.trim();
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(emailInput)) {
            document.getElementById('email').classList.add('is-invalid');
            document.getElementById('emailError').style.display = 'block';
        } else {
            document.getElementById('email').classList.remove('is-invalid');
            document.getElementById('emailError').style.display = 'none';
        }
    });
</script>

{{-- <script>
    document.addEventListener('DOMContentLoaded', function() {
        const roleCheckboxes = document.querySelectorAll('.role-checkbox');
        const skillsChecklist = document.querySelector('.skills-checklist');

        function updateCheckedCheckboxes() {
            
            const selectedRole = this.value;

            // Uncheck other role checkboxes based on the selected role
            if (selectedRole === 'Developer') {
                document.querySelector('[value="Senior Developer"]').checked = false;
                document.querySelector('[value="Tech Lead"]').checked = false;
            } else if (selectedRole === 'Senior Developer') {
                document.querySelector('[value="Developer"]').checked = false;
                document.querySelector('[value="Tech Lead"]').checked = false;
            } else if (selectedRole === 'Tech Lead') {
                document.querySelector('[value="Developer"]').checked = false;
                document.querySelector('[value="Senior Developer"]').checked = false;
            }

            let developerChecked = false;
            let seniorDeveloperChecked = false;
            let techLeadChecked = false;
            roleCheckboxes.forEach(function(roleCheckbox) {
                if (roleCheckbox.value === 'Developer' && roleCheckbox.checked) {
                    developerChecked = true;
                }
                if (roleCheckbox.value === 'Senior Developer' && roleCheckbox.checked) {
                    seniorDeveloperChecked = true;
                }
                if (roleCheckbox.value === 'Tech Lead' && roleCheckbox.checked) {
                    techLeadChecked = true;
                }
            });
            if (developerChecked || seniorDeveloperChecked || techLeadChecked) {
                skillsChecklist.style.display = 'block';
            } else {
                skillsChecklist.style.display = 'none';
            }
  
        }

        roleCheckboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', updateCheckedCheckboxes);
        });

        updateCheckedCheckboxes();
    });

    
    </script> --}}
@stop