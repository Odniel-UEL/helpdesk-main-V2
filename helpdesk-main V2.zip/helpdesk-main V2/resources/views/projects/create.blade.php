@extends('layouts.app')

@section('content')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>CREATE PROJECT</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-bell"></i> CREATE PROJECT</h4>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('projects.store') }}" method="POST">
                            @csrf

                            <div class="form-group">
                                <label>PROJECT NAME</label>
                                <input type="text" name="name" value="{{ old('name') }}" placeholder="Enter Project Title" class="form-control @error('name') is-invalid @enderror">

                                @error('name')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label>CLIENT</label>
                                <input type="text" name="client" value="{{ old('client') }}" placeholder="Enter Client name" class="form-control @error('client') is-invalid @enderror">

                                @error('client')
                                <div class="invalid-feedback" style="display: block">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>


                            <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i> SAVE</button>
                            <button class="btn btn-warning btn-reset" type="reset"><i class="fa fa-redo"></i> RESET</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='{{ url()->previous() }}'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        document.querySelector('.btn-reset').addEventListener('click', function() {
            // Ensure all fields are cleared
            document.querySelector('.form-horizontal').reset();
        });
    </script>
@stop