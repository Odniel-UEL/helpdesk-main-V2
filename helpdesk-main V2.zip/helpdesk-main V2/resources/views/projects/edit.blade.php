@extends('layouts.app')

@section('content')
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Edit project</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-bell"></i> Edit project</h4>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('projects.update', $project->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            
                            <div class="row">
                                <div class="form-group col-lg-6">
                                    <label>PROJECT NAME</label>
                                    <input type="text" name="name" value="{{ old('name', $project->name) }}" placeholder="Enter Project Title" class="form-control @error('name') is-invalid @enderror">
    
                                    @error('name')
                                    <div class="invalid-feedback" style="display: block">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
    
                                <div class="form-group col-lg-6">
                                    <label>CLIENT</label>
                                    <input type="text" name="client" value="{{ old('client',$project->client) }}" placeholder="Enter Client name" class="form-control @error('client') is-invalid @enderror">
    
                                    @error('client')
                                    <div class="invalid-feedback" style="display: block">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-lg-6">
                                    <label>CHANGE STATUS</label>
                                    <select name="status" id="status" class="form-control select-status @error('status') is-invalid @enderror" >
                                        <option value="">-- Change status --</option>
                                        @hasanyrole('Admin|Tech Lead')
                                        <option value="New" @if ($project->status == "New") selected @endif>New</option>
                                        <option value="Ongoing" @if ($project->status == "Ongoing") selected @endif>Ongoing</option>
                                        <option value="To be released" @if ($project->status == "To be released") selected @endif>To be released</option>
                                        <option value="Finished" @if ($project->status == "Finished") selected @endif>Finished</option>
                                        <option value="Cancelled" @if ($project->status == "Cancelled") selected @endif>Cancelled</option>
                                        @endhasanyrole
                                    </select>
                                </div>
                            </div>
                            
                            
                            


                            <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i> SAVE</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='{{ url()->previous() }}'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
@stop