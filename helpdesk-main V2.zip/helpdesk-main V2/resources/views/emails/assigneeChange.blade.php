<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ERP System</title>

    <style>
        body{
            font-family: 'Nunito', sans-serif;
            padding: 50px;
            }
            .card{
                border-radius: 4px;
                background: #fff;
                box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);
                transition: .3s transform cubic-bezier(.155,1.105,.295,1.12),.3s box-shadow,.3s -webkit-transform cubic-bezier(.155,1.105,.295,1.12);
            padding: 14px 80px 18px 36px;
            cursor: pointer;
            }

            .card h3{
            font-weight: 600;
            }

            .card-1{
            background-image: url(https://ionicframework.com/img/getting-started/ionic-native-card.png);
                background-repeat: no-repeat;
                background-position: right;
                background-size: 80px;
            }

            @media(max-width: 990px){
            .card{
                margin: 20px;
            }
            } 

    </style>

</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-1">
                <p>A ticket has been re-assigned to you.</p>
                <p><b>Project Name:</b>  {{ $project->name }}</p>
                <p><b>Problem Summary:</b>  {{ $ticket->problemsummary }}</p>
                <p><b>Description:</b>  {{ $ticket->problemdetail }}</p>
                <p><b>Priority:</b>  {{ $sla->name }}</p>
                <p><b>Need to be resolved before:</b>  {{ $ticket->resolutiondate }}</p>
                <br>
                <p>Click here to view ticket: <a href="http://127.0.0.1:8000/tickets/{{ $ticket->id }}/edit">{{ $ticket->number }}</a></p>
                <p><b>Requested for:</b>  {{ $customer->name }}</p>
                <p><b>Created:</b>  {{ $ticket->created_at }}</p>
                <br>
                <br>
                <p><b>This email has been sent by system. Do not reply to this email.</b></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>