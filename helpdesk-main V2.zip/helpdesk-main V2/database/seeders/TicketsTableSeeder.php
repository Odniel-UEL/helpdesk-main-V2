<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Ticket;

class TicketsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $ticket1=Ticket::create([
            'number' => 'TICK1000',
            'sla_id' => 3,
            'customer_id' => 1,
            'project_id' => 1,
            'openedby' => 1,
            'problemsummary' => 'New feature to be added',
            'problemdetail' => 'Test Details',
            'status' => 'Assigned',
            'assignee' => 3,
            'assigneddate' => '2024-05-25 14:48:19',
            'resolutionHours' => 4,
            'resolutiondate' => '2024-05-25 18:48:19',
            'resolveddate' => null,
            'progress_percentage' => null,
        ]);

        $ticket2=Ticket::create([
            'number' => 'TICK1001',
            'sla_id' => 3,
            'customer_id' => 2,
            'project_id' => 2,
            'openedby' => 1,
            'problemsummary' => 'Change the dropdown',
            'problemdetail' => 'Test Details',
            'status' => 'Assigned',
            'assignee' => 4,
            'assigneddate' => '2024-05-25 15:30:00',
            'resolutionHours' => 4,
            'resolutiondate' => '2024-05-25 19:30:00',
            'resolveddate' => null,
            'progress_percentage' => null,
        ]);

        Ticket::create([
            'number' => 'TICK1002',
            'sla_id' => 4,
            'customer_id' => 2,
            'project_id' => 2,
            'openedby' => 1,
            'problemsummary' => 'Make font bigger',
            'problemdetail' => 'Test Details',
            'status' => 'Assigned',
            'assignee' => 5,
            'assigneddate' => '2024-05-25 15:40:00',
            'resolutionHours' => 8,
            'resolutiondate' => '2024-05-25 19:40:00',
            'resolveddate' => null,
            'progress_percentage' => null,
        ]);

    }
}
