<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Sla;

class SLATableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $Urgent = Sla::create([
            'name'=>'Urgent',
            'resolution'=>24,
        ]);
        $High = Sla::create([
            'name'=>'High',
            'resolution'=>72,
        ]);
        $Medium = Sla::create([
            'name'=>'Medium',
            'resolution'=>168,
        ]);
        $Low = Sla::create([
            'name'=>'Low',
            'resolution'=>504,
        ]);
    }
}
