<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Customer;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $customer1 = Customer::create([
            'user_id'     => 12,
            'firstname' => "James",
            'lastname'  => "Barnett",
            'address'     => "55, BMD Road. Colombo",
            'phone'     => "0774585256",
            'email'     => "james@gmail.com",            
            'project_id'     => 1,
            'isActive'     => 1,
        ]);

        $customer2 = Customer::create([
            'user_id'     => 13,
            'firstname' => "Dan",
            'lastname'  => "Turnar",
            'address'     => "79, IL Road. Colombo",
            'phone'     => "0769635874",
            'email'     => "dan@gmail.com",            
            'project_id'     => 2,
            'isActive'     => 1,
        ]);
    }
}
