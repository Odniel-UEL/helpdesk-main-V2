<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Project;

class ProjectTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $Nars = Project::create([
            'name'=>'NARS',
            'client'=>'Adidas',
            'status' => 'Ongoing',
        ]);

        $Oaars = Project::create([
            'name'=>'OAARS',
            'client'=>'VMX',
            'status' => 'Ongoing',
        ]);
    }
}
