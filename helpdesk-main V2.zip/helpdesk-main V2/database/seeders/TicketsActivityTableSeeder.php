<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\TicketActivity;

class TicketsActivityTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TicketActivity::create([
            'ticket_id' => 1, 
            'activity_data' => [
                'Project' => 'NARS',
                'status' => 'New',
                'Priority' => 'Medium',
                'Opened By' => 'Admin Admin',
                'Created' => '2024-05-25T07:45:57.000000Z',
            ],
            'user_id' => 1, 
        ]);

        TicketActivity::create([
            'ticket_id' => 1,
            'activity_data' => [
                'Assigned to' => 'Kamal Mas',
                'Resolution Hours' => '4',
                'Status' => 'Assigned',
            ],
            'user_id' => 1,
        ]);

        TicketActivity::create([
            'ticket_id' => 2,
            'activity_data' => [
                'Project' => 'OAARS',
                'status' => 'New',
                'Priority' => 'Medium',
                'Opened By' => 'Admin Admin',
                'Created' => '2024-05-25T07:45:57.000000Z',
            ],
            'user_id' => 1,
        ]);

        TicketActivity::create([
            'ticket_id' => 2,
            'activity_data' => [
                'Assigned to' => 'Amal Pih',
                'Resolution Hours' => '4',
                'Status' => 'Assigned',
            ],
            'user_id' => 1,
        ]);

        TicketActivity::create([
            'ticket_id' => 3,
            'activity_data' => [
                'Project' => 'OAARS',
                'status' => 'New',
                'Priority' => 'Medium',
                'Opened By' => 'Admin Admin',
                'Created' => '2024-05-25T07:45:57.000000Z',
            ],
            'user_id' => 1,
        ]);

        TicketActivity::create([
            'ticket_id' => 3,
            'activity_data' => [
                'Assigned to' => 'Duran Mas',
                'Resolution Hours' => '8',
                'Status' => 'Assigned',
            ],
            'user_id' => 1,
        ]);
    }
}
