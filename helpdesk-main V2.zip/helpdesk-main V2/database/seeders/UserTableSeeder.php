<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        $role = Role::find(1);
        $role2 = Role::find(2);
        $role3 = Role::find(3);
        $role4 = Role::find(4);
        $role5 = Role::find(5);
        $role6 = Role::find(6);

        $admin = User::create([
            'firstname'=>'Admin',
            'lastname'=>'Admin',
            'email'=>'admin@admin.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        $admin->assignRole($role);
        $role->givePermissionTo(Permission::all());

        $Chamalka = User::create([
            'firstname'=>'Chamalka',
            'lastname'=>'Sed',
            'email'=>'mawsa3454@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        $Chamalka->assignRole($role2);

        $Kamal = User::create([
            'firstname'=>'Kamal',
            'lastname'=>'Mas',
            'email'=>'Kamal@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);
        
        $Kamal->assignRole($role6);

        $Amal = User::create([
            'firstname'=>'Amal',
            'lastname'=>'Pih',
            'email'=>'Amal@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        
        $Amal->assignRole($role3);

        $Duran = User::create([
            'firstname'=>'Duran',
            'lastname'=>'Mas',
            'email'=>'Duran@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);
        
        $Duran->assignRole($role4);

        $Avish = User::create([
            'firstname'=>'Avish',
            'lastname'=>'Pih',
            'email'=>'Avish@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        
        $Avish->assignRole($role4);

        $Bineth = User::create([
            'firstname'=>'Bineth',
            'lastname'=>'Mas',
            'email'=>'Bineth@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);
        
        $Bineth->assignRole($role6);

        $Rahul = User::create([
            'firstname'=>'Rahul',
            'lastname'=>'Pih',
            'email'=>'Rahul@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        
        $Rahul->assignRole($role4);

        $Shamika = User::create([
            'firstname'=>'Shamika',
            'lastname'=>'Mas',
            'email'=>'Shamika@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);
        
        $Shamika->assignRole($role3);

        $Shan = User::create([
            'firstname'=>'Shan',
            'lastname'=>'Pih',
            'email'=>'Shan@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        
        $Shan->assignRole($role6);

        $Vihanga = User::create([
            'firstname'=>'Vihanga',
            'lastname'=>'Pih',
            'email'=>'Vihanga@gmail.com',
            'password'=>bcrypt('password'),
            'isActive'=>1,
        ]);

        
        $Vihanga->assignRole($role4);

        $customer1 = User::create([
            'firstname' => "James",
            'lastname'  => "Barnett",
            'email'     => "james@gmail.com",
            'password'  => bcrypt('password'),
            'isActive'=>1,
        ]);

        $customer1->assignRole($role5);


        $customer2 = User::create([
            'firstname' => "Dan",
            'lastname'  => "Turnar",
            'email'     => "dan@gmail.com",
            'password'  => bcrypt('password'),
            'isActive'=>1,
        ]);

        $customer2->assignRole($role5);
        
        

    }
}
