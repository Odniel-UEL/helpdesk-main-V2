<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role = Role::create([
            'name' => 'Admin'
        ]);

        $role2 = Role::create([
            'name' => 'Tech Lead'
        ]);

        $role3 = Role::create([
            'name' => 'Developer'
        ]);

        $role4 = Role::create([
            'name' => 'Senior Developer'
        ]);
        
        $role5 = Role::create([
            'name' => 'Customer'
        ]);

        $role6 = Role::create([
            'name' => 'Junior Developer'
        ]);

        
    }
}
