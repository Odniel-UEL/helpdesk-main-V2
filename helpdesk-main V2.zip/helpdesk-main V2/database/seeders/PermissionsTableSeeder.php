<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //permission for tickets
        Permission::create(['name' => 'tickets.index','description' => 'Access to tickets table']);
        Permission::create(['name' => 'tickets.create','description' => 'Access to ticket creation']);
        Permission::create(['name' => 'tickets.edit','description' => 'Access to tickets edit']);
        Permission::create(['name' => 'tickets.delete','description' => 'Access to tickets delete']);

        //permission for slas
        Permission::create(['name' => 'slas.index','description' => 'Access to SLAs table']);
        Permission::create(['name' => 'slas.create','description' => 'Access to SLAs creation']);
        Permission::create(['name' => 'slas.edit','description' => 'Access to SLAs edit']);
        Permission::create(['name' => 'slas.delete','description' => 'Access to SLAs delete']);

        //permission for users
        Permission::create(['name' => 'users.index','description' => 'Access to Users table']);
        Permission::create(['name' => 'users.create','description' => 'Access to Users creation']);
        Permission::create(['name' => 'users.edit','description' => 'Access to Users edit']);
        Permission::create(['name' => 'users.delete','description' => 'Access to Users delete']);

        //permission for roles
        Permission::create(['name' => 'roles.index','description' => 'Access to Roles table']);
        Permission::create(['name' => 'roles.create','description' => 'Access to Roles creation']);
        Permission::create(['name' => 'roles.edit','description' => 'Access to Roles edit']);
        Permission::create(['name' => 'roles.delete','description' => 'Access to Roles delete']);

        //permission for customers
        Permission::create(['name' => 'customers.index','description' => 'Access to Customers table']);
        Permission::create(['name' => 'customers.create','description' => 'Access to Customers creation']);
        Permission::create(['name' => 'customers.edit','description' => 'Access to Customers edit']);
        Permission::create(['name' => 'customers.delete','description' => 'Access to Customers delete']);

        //permission for projects
        Permission::create(['name' => 'projects.index','description' => 'Access to Projects table']);
        Permission::create(['name' => 'projects.create','description' => 'Access to Projects creation']);
        Permission::create(['name' => 'projects.edit','description' => 'Access to Projects edit']);
        Permission::create(['name' => 'projects.delete','description' => 'Access to Projects delete']);

        //permission for log_emails
        Permission::create(['name' => 'log_emails.index','description' => 'Access to Email logs table']);
        Permission::create(['name' => 'log_emails.create','description' => 'Access to Email logs creation']);
        Permission::create(['name' => 'log_emails.edit','description' => 'Access to Email logs edit']);
        Permission::create(['name' => 'log_emails.delete','description' => 'Access to Email logs delete']);

        //permission for log_users
        Permission::create(['name' => 'log_users.index','description' => 'Access to User logs table']);

        //permission for permissions
        Permission::create(['name' => 'permissions.index','description' => 'Access to Permissions table']);
        Permission::create(['name' => 'permissions.create','description' => 'Access to Permissions creation']);

        //permission for reports
        Permission::create(['name' => 'reports.customerWise','description' => 'Access to Customer Wise Report']);
        Permission::create(['name' => 'reports.developerWise','description' => 'Access to Developer Wise Report']);
    }
}
