<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('number');
            
            // Foreign key for Service Level Agreement (SLA)
            $table->foreignId('sla_id')->nullable()->constrained(); // Assuming it references the SLA table
            
            // Foreign key for Customer
            $table->foreignId('customer_id')->constrained(); // Assuming it references the Customer table
            
            // Foreign key for Project
            $table->foreignId('project_id')->constrained(); // Assuming it references the Project table
            
            // Foreign key for User who opened the ticket
            $table->foreignId('openedby')->nullable()->constrained('users'); // Assuming it references the User table
            
            $table->string('problemsummary');
            $table->string('problemdetail')->nullable();
            $table->string('status');
            
            // Foreign key for User assigned to the ticket
            $table->foreignId('assignee')->nullable()->constrained('users'); // Assuming it references the User table
            
            $table->dateTime('assigneddate')->nullable();
            $table->integer('resolutionHours')->nullable();
            $table->dateTime('resolutiondate')->nullable();
            $table->dateTime('resolveddate')->nullable();
            $table->integer('progress_percentage')->nullable();
            $table->timestamps();
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tickets');
    }
}
