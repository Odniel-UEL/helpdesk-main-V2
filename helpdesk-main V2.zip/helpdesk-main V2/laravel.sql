-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2024 at 04:20 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 1,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `user_id`, `firstname`, `lastname`, `address`, `phone`, `email`, `isActive`, `project_id`, `created_at`, `updated_at`) VALUES
(1, 12, 'James', 'Barnett', '55, BMD Road. Colombo', '0774585256', 'james@gmail.com', 1, 1, '2024-10-19 14:19:58', '2024-10-19 14:19:58'),
(2, 13, 'Dan', 'Turnar', '79, IL Road. Colombo', '0769635874', 'dan@gmail.com', 1, 2, '2024-10-19 14:19:58', '2024-10-19 14:19:58');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_emails`
--

CREATE TABLE `log_emails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_id` bigint(20) UNSIGNED NOT NULL,
  `emailto` varchar(255) NOT NULL,
  `emailcc` varchar(255) NOT NULL,
  `emailbcc` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `senddate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_users`
--

CREATE TABLE `log_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(255) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `log` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2024_04_13_000000_create_failed_jobs_table', 1),
(2, '2024_04_13_000000_create_users_table', 1),
(3, '2024_04_13_074910_create_jobs_table', 1),
(4, '2024_04_13_100000_create_password_resets_table', 1),
(5, '2024_04_13_130339_create_log_users_table', 1),
(6, '2024_04_13_150701_create_slas_table', 1),
(7, '2024_04_13_213738_create_permission_tables', 1),
(8, '2024_04_13_232306_create_projects_table', 1),
(9, '2024_04_14_143915_create_customers_table', 1),
(10, '2024_04_14_233323_create_tickets_table', 1),
(11, '2024_04_15_123910_create_log_emails_table', 1),
(12, '2024_04_23_225734_create_ticket_activities_table', 1),
(13, '2024_04_28_213753_create_ticket_worknotes_table', 1),
(14, '2024_05_23_100256_add_description_to_permissions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(3, 'App\\Models\\User', 4),
(3, 'App\\Models\\User', 9),
(4, 'App\\Models\\User', 5),
(4, 'App\\Models\\User', 6),
(4, 'App\\Models\\User', 8),
(4, 'App\\Models\\User', 11),
(5, 'App\\Models\\User', 12),
(5, 'App\\Models\\User', 13),
(6, 'App\\Models\\User', 3),
(6, 'App\\Models\\User', 7),
(6, 'App\\Models\\User', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `description`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'tickets.index', 'Access to tickets table', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(2, 'tickets.create', 'Access to ticket creation', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(3, 'tickets.edit', 'Access to tickets edit', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(4, 'tickets.delete', 'Access to tickets delete', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(5, 'slas.index', 'Access to SLAs table', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(6, 'slas.create', 'Access to SLAs creation', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(7, 'slas.edit', 'Access to SLAs edit', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(8, 'slas.delete', 'Access to SLAs delete', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(9, 'users.index', 'Access to Users table', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(10, 'users.create', 'Access to Users creation', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(11, 'users.edit', 'Access to Users edit', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(12, 'users.delete', 'Access to Users delete', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(13, 'roles.index', 'Access to Roles table', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(14, 'roles.create', 'Access to Roles creation', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(15, 'roles.edit', 'Access to Roles edit', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(16, 'roles.delete', 'Access to Roles delete', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(17, 'customers.index', 'Access to Customers table', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(18, 'customers.create', 'Access to Customers creation', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(19, 'customers.edit', 'Access to Customers edit', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(20, 'customers.delete', 'Access to Customers delete', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(21, 'projects.index', 'Access to Projects table', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(22, 'projects.create', 'Access to Projects creation', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(23, 'projects.edit', 'Access to Projects edit', 'web', '2024-10-19 14:19:54', '2024-10-19 14:19:54'),
(24, 'projects.delete', 'Access to Projects delete', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(25, 'log_emails.index', 'Access to Email logs table', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(26, 'log_emails.create', 'Access to Email logs creation', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(27, 'log_emails.edit', 'Access to Email logs edit', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(28, 'log_emails.delete', 'Access to Email logs delete', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(29, 'log_users.index', 'Access to User logs table', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(30, 'permissions.index', 'Access to Permissions table', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(31, 'permissions.create', 'Access to Permissions creation', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(32, 'reports.customerWise', 'Access to Customer Wise Report', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(33, 'reports.developerWise', 'Access to Developer Wise Report', 'web', '2024-10-19 14:19:55', '2024-10-19 14:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `client` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `client`, `status`, `created_at`, `updated_at`) VALUES
(1, 'NARS', 'Adidas', 'Ongoing', '2024-10-19 14:19:58', '2024-10-19 14:19:58'),
(2, 'OAARS', 'VMX', 'Ongoing', '2024-10-19 14:19:58', '2024-10-19 14:19:58');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'web', '2024-10-19 14:19:53', '2024-10-19 14:19:53'),
(2, 'Tech Lead', 'web', '2024-10-19 14:19:53', '2024-10-19 14:19:53'),
(3, 'Developer', 'web', '2024-10-19 14:19:53', '2024-10-19 14:19:53'),
(4, 'Senior Developer', 'web', '2024-10-19 14:19:53', '2024-10-19 14:19:53'),
(5, 'Customer', 'web', '2024-10-19 14:19:53', '2024-10-19 14:19:53'),
(6, 'Junior Developer', 'web', '2024-10-19 14:19:53', '2024-10-19 14:19:53');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1);

-- --------------------------------------------------------

--
-- Table structure for table `slas`
--

CREATE TABLE `slas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `resolution` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slas`
--

INSERT INTO `slas` (`id`, `name`, `resolution`) VALUES
(1, 'Urgent', 24),
(2, 'High', 72),
(3, 'Medium', 168),
(4, 'Low', 504);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(255) NOT NULL,
  `sla_id` bigint(20) UNSIGNED DEFAULT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `openedby` bigint(20) UNSIGNED DEFAULT NULL,
  `problemsummary` varchar(255) NOT NULL,
  `problemdetail` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `assignee` bigint(20) UNSIGNED DEFAULT NULL,
  `assigneddate` datetime DEFAULT NULL,
  `resolutionHours` int(11) DEFAULT NULL,
  `resolutiondate` datetime DEFAULT NULL,
  `resolveddate` datetime DEFAULT NULL,
  `progress_percentage` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_activities`
--

CREATE TABLE `ticket_activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_id` bigint(20) UNSIGNED NOT NULL,
  `activity_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`activity_data`)),
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_worknotes`
--

CREATE TABLE `ticket_worknotes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ticket_id` bigint(20) UNSIGNED NOT NULL,
  `work_notes` text DEFAULT NULL,
  `customer_comments` text DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT 1,
  `profile_picture` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `email_verified_at`, `password`, `isActive`, `profile_picture`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'Admin', 'admin@admin.com', NULL, '$2y$10$ZU4O6MCcr5KQT02UrIw5jO9XbVrl7HSX1fG6X6bHWAssE93yAgWoG', 1, NULL, NULL, '2024-10-19 14:19:55', '2024-10-19 14:19:55'),
(2, 'Chamalka', 'Sed', 'mawsa3454@gmail.com', NULL, '$2y$10$Y2JNhhN2BtVSFwfwWGOjTeqzYrTtqkIcDul3R42ZCWmVOHDfeDWue', 1, NULL, NULL, '2024-10-19 14:19:56', '2024-10-19 14:19:56'),
(3, 'Kamal', 'Mas', 'Kamal@gmail.com', NULL, '$2y$10$cczUJNHZrnwAfx7QG4tmlO8io1DjjGdF0yIU7CpS1Y7biD1GUg2RC', 1, NULL, NULL, '2024-10-19 14:19:56', '2024-10-19 14:19:56'),
(4, 'Amal', 'Pih', 'Amal@gmail.com', NULL, '$2y$10$UMReBtdRGGqr87PXlInHk.ntN7kmmFUOx2YHL66QUT/Goh.gFjMrq', 1, NULL, NULL, '2024-10-19 14:19:56', '2024-10-19 14:19:56'),
(5, 'Duran', 'Mas', 'Duran@gmail.com', NULL, '$2y$10$XTdwg3cixE3oD8nMiovgyevdlCZFzCmElH4Et0AZ50d8kIVyuSGkW', 1, NULL, NULL, '2024-10-19 14:19:56', '2024-10-19 14:19:56'),
(6, 'Avish', 'Pih', 'Avish@gmail.com', NULL, '$2y$10$2z2bmqWjROnC6aW3d1MQB.GpT3jDoTdoYaRJcddTJiYv6kfvMpviq', 1, NULL, NULL, '2024-10-19 14:19:56', '2024-10-19 14:19:56'),
(7, 'Bineth', 'Mas', 'Bineth@gmail.com', NULL, '$2y$10$khHpTLcla4BUAq3mmyvotODa5TTA5G9dDrW00R.x2zHiP6owkgQve', 1, NULL, NULL, '2024-10-19 14:19:57', '2024-10-19 14:19:57'),
(8, 'Rahul', 'Pih', 'Rahul@gmail.com', NULL, '$2y$10$3EFlmf/TbYcDTA.0vFbZk.x8ti1tUK8K6NPW5bGhax4V.8Vz/BvRK', 1, NULL, NULL, '2024-10-19 14:19:57', '2024-10-19 14:19:57'),
(9, 'Shamika', 'Mas', 'Shamika@gmail.com', NULL, '$2y$10$dJ6cDaCc1WNnEJhbC2IIHeSaiHU4Bi9Fqi6ucm0PviYfoznewjzAu', 1, NULL, NULL, '2024-10-19 14:19:57', '2024-10-19 14:19:57'),
(10, 'Shan', 'Pih', 'Shan@gmail.com', NULL, '$2y$10$s4wI6W89Ge/Z2n26O9kgtOjh./G2ebOssDrOV62RrpSOvADNu/vxC', 1, NULL, NULL, '2024-10-19 14:19:57', '2024-10-19 14:19:57'),
(11, 'Vihanga', 'Pih', 'Vihanga@gmail.com', NULL, '$2y$10$loXEkRQWIKZwPF5RxOa8L.H36hBAlbVGgOSvgCCiq6OkR69QjL5My', 1, NULL, NULL, '2024-10-19 14:19:57', '2024-10-19 14:19:57'),
(12, 'James', 'Barnett', 'james@gmail.com', NULL, '$2y$10$GBuuzkxuYQGJRM6fy9zWTeRHEYJyscZK7Ds02HDTs2fx7zFCDDuF2', 1, NULL, NULL, '2024-10-19 14:19:57', '2024-10-19 14:19:57'),
(13, 'Dan', 'Turnar', 'dan@gmail.com', NULL, '$2y$10$Bg/QzPOEQJtakZv02xflVeIpLMM2dSx3unVjcEQkQ1/g7EWMbN35e', 1, NULL, NULL, '2024-10-19 14:19:58', '2024-10-19 14:19:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customers_email_unique` (`email`),
  ADD KEY `customers_user_id_foreign` (`user_id`),
  ADD KEY `customers_project_id_foreign` (`project_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `log_emails`
--
ALTER TABLE `log_emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `log_emails_ticket_id_foreign` (`ticket_id`);

--
-- Indexes for table `log_users`
--
ALTER TABLE `log_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `log_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `slas`
--
ALTER TABLE `slas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tickets_sla_id_foreign` (`sla_id`),
  ADD KEY `tickets_customer_id_foreign` (`customer_id`),
  ADD KEY `tickets_project_id_foreign` (`project_id`),
  ADD KEY `tickets_openedby_foreign` (`openedby`),
  ADD KEY `tickets_assignee_foreign` (`assignee`);

--
-- Indexes for table `ticket_activities`
--
ALTER TABLE `ticket_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_activities_ticket_id_foreign` (`ticket_id`),
  ADD KEY `ticket_activities_user_id_foreign` (`user_id`);

--
-- Indexes for table `ticket_worknotes`
--
ALTER TABLE `ticket_worknotes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_worknotes_ticket_id_foreign` (`ticket_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log_emails`
--
ALTER TABLE `log_emails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log_users`
--
ALTER TABLE `log_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slas`
--
ALTER TABLE `slas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_activities`
--
ALTER TABLE `ticket_activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_worknotes`
--
ALTER TABLE `ticket_worknotes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  ADD CONSTRAINT `customers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `log_emails`
--
ALTER TABLE `log_emails`
  ADD CONSTRAINT `log_emails_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`);

--
-- Constraints for table `log_users`
--
ALTER TABLE `log_users`
  ADD CONSTRAINT `log_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_assignee_foreign` FOREIGN KEY (`assignee`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tickets_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `tickets_openedby_foreign` FOREIGN KEY (`openedby`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tickets_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  ADD CONSTRAINT `tickets_sla_id_foreign` FOREIGN KEY (`sla_id`) REFERENCES `slas` (`id`);

--
-- Constraints for table `ticket_activities`
--
ALTER TABLE `ticket_activities`
  ADD CONSTRAINT `ticket_activities_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticket_activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ticket_worknotes`
--
ALTER TABLE `ticket_worknotes`
  ADD CONSTRAINT `ticket_worknotes_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
