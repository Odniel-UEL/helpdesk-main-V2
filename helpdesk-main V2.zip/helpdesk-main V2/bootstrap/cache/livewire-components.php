<?php return array (
  'customer-project' => 'App\\Http\\Livewire\\CustomerProject',
  'customerdata' => 'App\\Http\\Livewire\\Customerdata',
  'test' => 'App\\Http\\Livewire\\Test',
  'user-form' => 'App\\Http\\Livewire\\UserForm',
);