<?php

use App\Models\News;
use App\Models\User;
use App\Models\Ticket;
use App\Models\Log_user;
use App\Services\ReportService;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SlaController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\LogUserController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\ReportController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

// To check the authentication true or false
Route::get('/check-auth', function() {
    return response()->json(['authenticated' => auth()->check()]);
});


Route::group(['middleware' => 'auth'], function() {
    Route::get('/dashboard', function () {
        $report = new ReportService(now()->format('Y'), now()->format('m'));
        $allReports = $report->getAllDeveloperTickets();
        $user = new User();
        return view('dashboard', compact('report', 'allReports', 'user'));
    })->name('dashboard');

    Route::resource('tickets', TicketController::class);

    Route::resource('permissions', PermissionController::class)->except([
        'show'
    ]);

    Route::resource('roles', RoleController::class)->except([
        'show'
    ]);

    Route::resource('users', UserController::class)->except([
        'show'
    ]);

    Route::resource('customers', CustomerController::class)->except([
        'show'
    ]);

    Route::resource('slas', SlaController::class)->except([
        'show'
    ]);

    Route::resource('projects', ProjectController::class)->except([
        'show'
    ]);


    Route::get('user-log', [LogUserController::class, 'index'])->name('userlog.index');

    
    Route::get('get-users', [UserController::class, 'getUsers'])->name('get.users');  

    
    // Route::post('/tickets/{ticketId}/activities', [TicketController::class, 'storeActivity'])->name('tickets.activities.store');

    Route::get('/customerReports', [ReportController::class, 'customerWise'])->name('reports.customerWise');
    Route::get('/reports/projects/{customerId}', [ReportController::class, 'getProjects']);
    Route::post('/reports/generate', [ReportController::class, 'generateCustomerReport'])->name('reports.generate');

    Route::get('/developerReports', [ReportController::class, 'developerWise'])->name('reports.developerWise');
    Route::post('/reports/generateDev', [ReportController::class, 'generateDeveloperReport'])->name('reports.generateDev');


    
});



//permissions




require __DIR__.'/auth.php';
