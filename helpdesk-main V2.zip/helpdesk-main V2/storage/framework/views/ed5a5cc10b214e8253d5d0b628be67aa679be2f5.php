<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Edit project</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-bell"></i> Edit project</h4>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            
                            <div class="row">
                                <div class="form-group col-lg-6">
                                    <label>PROJECT NAME</label>
                                    <input type="text" name="name" value="<?php echo e(old('name', $project->name)); ?>" placeholder="Enter Project Title" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" style="display: block">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
    
                                <div class="form-group col-lg-6">
                                    <label>CLIENT</label>
                                    <input type="text" name="client" value="<?php echo e(old('client',$project->client)); ?>" placeholder="Enter Client name" class="form-control <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    
                                    <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback" style="display: block">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-lg-6">
                                    <label>CHANGE STATUS</label>
                                    <select name="status" id="status" class="form-control select-status <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                        <option value="">-- Change status --</option>
                                        <?php if(auth()->check() && auth()->user()->hasAnyRole('Admin|Tech Lead')): ?>
                                        <option value="New" <?php if($project->status == "New"): ?> selected <?php endif; ?>>New</option>
                                        <option value="Ongoing" <?php if($project->status == "Ongoing"): ?> selected <?php endif; ?>>Ongoing</option>
                                        <option value="To be released" <?php if($project->status == "To be released"): ?> selected <?php endif; ?>>To be released</option>
                                        <option value="Finished" <?php if($project->status == "Finished"): ?> selected <?php endif; ?>>Finished</option>
                                        <option value="Cancelled" <?php if($project->status == "Cancelled"): ?> selected <?php endif; ?>>Cancelled</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            
                            
                            


                            <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i> SAVE</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='<?php echo e(url()->previous()); ?>'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views/projects/edit.blade.php ENDPATH**/ ?>