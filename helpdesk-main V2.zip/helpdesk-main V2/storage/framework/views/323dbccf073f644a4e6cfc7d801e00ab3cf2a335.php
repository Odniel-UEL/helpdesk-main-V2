<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Report</h1>
        </div>

        <div class="section-body">

            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-unlock"></i> Customer Wise Report</h4>
                </div>

                <div class="card-body">
                    <form id="reportForm" class="row">
                        <div class="col-lg-9 row">
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label>Date Range:</label>
                                    <input type="text" id="dateRange" class="form-control" name="date_range">
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label>Customer:</label>
                                    <select id="customerSelect" class="form-control" name="customer_id">
                                        <option value="">Select Customer</option>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->firstname); ?> <?php echo e($customer->lastname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">            
                                    <label>Project:</label>
                                    <input type="text" id="project" readonly class="form-control" name="project">
                                </div>
                            </div>
                        </div>                        
                        <div class="col-lg-3 d-flex align-items-center justify-content-center">
                            <button class="btn btn-primary mr-1 btn-submit" id="generateReport">Generate Report</button>
                        </div>
                    </form>
                    
                    <div class="table-responsive" id="reportTable">
                        <table id="reportDataTable" class="table table-bordered mt-4">
                            <thead>
                                <tr>
                                    <th>Created</th>
                                    <th>Number</th>
                                    <th>Priority</th>
                                    <th>Project</th>
                                    <th>Problem</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Table rows will be inserted here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    flatpickr("#dateRange", {
        mode: "range",
        dateFormat: "Y-m-d",
    });

    $('#customerSelect').change(function() {
        var customerId = $(this).val();
        if(customerId) {
            $.get('/reports/projects/' + customerId, function(data) {
                $('#project').val(data.project_name)
            });
        } else {
            $('#project').val('');
        }
    });

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {

        $('#generateReport').click(function(e) {
            e.preventDefault();

            $.ajax({
                url: '<?php echo e(route('reports.generate')); ?>',
                method: 'POST',
                data: $('#reportForm').serialize(),
                success: function(response) {
                    console.log('Response:', response); // Debugging line
                    table.clear().draw();
                    if (response.length > 0) {
                        response.forEach(function(ticket) {
                            table.row.add([
                                new Date(ticket.created_at).toLocaleString(),
                                ticket.number,
                                ticket.sla ? ticket.sla.name : 'N/A',
                                ticket.project ? ticket.project.name : 'N/A',
                                ticket.problemsummary,
                                ticket.status
                            ]).draw();
                        });
                    } else {
                        table.row.add(['No tickets found for the selected date range.', '', '', '', '', '']).draw();
                    }
                },
                error: function() {
                    table.clear().draw();
                    table.row.add(['An error occurred while generating the report. Please try again.', '', '', '', '', '']).draw();
                }
            });
        });


        var table = $('#reportDataTable').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    text: 'Export PDF',
                    action: function () {
                        var customerName = $('#customerSelect option:selected').text().replace(/\s+/g, '_'); // Replace spaces with underscores
                        var dateRange = $('#dateRange').val().replace(/\s+/g, '_').replace(/:/g, '-'); // Replace spaces with underscores and colon with hyphen

                        var docDefinition = {
                            content: [
                                { text: 'Customer Wise Ticket Report', style: 'header',alignment: 'center' },
                                { text: `Date Range: ${$('#dateRange').val()}`, margin: [0, 10] },
                                { text: `Customer: ${$('#customerSelect option:selected').text()}`, margin: [0, 5] },
                                { text: `Project: ${$('#project').val()}`, margin: [0, 5] },
                                { text: '', margin: [0, 20] }, // Space between title and table
                                {
                                    table: {
                                        headerRows: 1,
                                        widths: [ '*', '*', '*', '*', '*', '*' ],
                                        body: [
                                            [
                                                { text: 'Created', style: 'tableHeader' },
                                                { text: 'Number', style: 'tableHeader' },
                                                { text: 'Priority', style: 'tableHeader' },
                                                { text: 'Project', style: 'tableHeader' },
                                                { text: 'Problem', style: 'tableHeader' },
                                                { text: 'Status', style: 'tableHeader' }
                                            ],
                                            ...table.rows({ search: 'applied' }).data().toArray().map(row => [
                                                row[0], row[1], row[2], row[3], row[4], row[5]
                                            ])
                                        ]
                                    }
                                }
                            ],
                            styles: {
                                header: {
                                    fontSize: 18,
                                    bold: true
                                },
                                table: {
                                    margin: [0, 10, 0, 15]
                                },
                                tableHeader: {
                                    bold: true,
                                    fontSize: 12,
                                    color: 'black'
                                }
                            }
                        };
                        var fileName = `Customer_Wise_Ticket_Report_${customerName}_${dateRange}.pdf`;
                        pdfMake.createPdf(docDefinition).download(fileName);
                    }
                }
            ],
            "paging": false,
            "info": false,
            "searching": false
        });

        
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views/reports/customerWise.blade.php ENDPATH**/ ?>