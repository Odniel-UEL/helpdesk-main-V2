<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ERP System</title>

    <style>
        body{
            font-family: 'Nunito', sans-serif;
            padding: 50px;
            }
            .card{
                border-radius: 4px;
                background: #fff;
                box-shadow: 0 6px 10px rgba(0,0,0,.08), 0 0 6px rgba(0,0,0,.05);
                transition: .3s transform cubic-bezier(.155,1.105,.295,1.12),.3s box-shadow,.3s -webkit-transform cubic-bezier(.155,1.105,.295,1.12);
            padding: 14px 80px 18px 36px;
            cursor: pointer;
            }

            .card h3{
            font-weight: 600;
            }

            .card-1{
            background-image: url(https://ionicframework.com/img/getting-started/ionic-native-card.png);
                background-repeat: no-repeat;
                background-position: right;
                background-size: 80px;
            }

            @media(max-width: 990px){
            .card{
                margin: 20px;
            }
            } 

    </style>

</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-1">
                    <?php if(!is_null($user)): ?>
                        <p>A ticket has been assigned to you.</p>
                        <p><b>Assignee Name:</b>  <?php echo e($user->name); ?></p>
                    <?php else: ?>
                        <p>A ticket has been created.</p>
                    <?php endif; ?>
                    <p><b>Project Name:</b>  <?php echo e($project->name); ?></p>
                    <p><b>Problem Summary:</b>  <?php echo e($ticket->problemsummary); ?></p>
                    <p><b>Description:</b>  <?php echo e($ticket->problemdetail); ?></p>
                    <p><b>Priority:</b>  <?php echo e($sla->name); ?></p>
                    <p><b>Need to be resolved before:</b>  <?php echo e($ticket->resolutiondate); ?></p>
                    <br>
                    <p>Click here to view ticket: <a href="http://127.0.0.1:8000/tickets/<?php echo e($ticket->id); ?>/edit"><?php echo e($ticket->number); ?></a></p>
                    <p><b>Requested for:</b>  <?php echo e($customer->name); ?></p>
                    <p><b>Created:</b>  <?php echo e($ticket->created_at); ?></p>
                    <br>
                    <br>
                    <p><b>This email has been sent by system. Do not reply to this email.</b></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views/emails/notify.blade.php ENDPATH**/ ?>