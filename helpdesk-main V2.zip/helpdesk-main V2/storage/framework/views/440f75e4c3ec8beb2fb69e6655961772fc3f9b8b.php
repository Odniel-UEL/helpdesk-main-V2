<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Permissions</h1>
            </div>
            <div class="section-body">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-key"></i> Permissions</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('permissions.index')); ?>" method="GET">
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.create')): ?>
                                <div class="input-group-prepend">
                                    <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary" style="padding-top: 10px;"><i class="fa fa-plus-circle"></i> CREATE</a>
                                </div>
                            <?php endif; ?>
                                    <input type="text" class="form-control" name="q"
                                    placeholder="Search based on name">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btnprimary">
                                            <i class="fa fa-search"></i> SEARCH
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col" style="text-align: center;width:6%">ID.</th>
                                        <th scope="col">PERMISSION NAME</th>
                                        <th scope="col">DESCRIPTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row" style="text-align:
                                        center">
                                        
                                        <?php echo e($permission->id); ?>

                                        </th>
                                        <td><?php echo e($permission->name); ?></td>
                                        <td><?php echo e($permission->description); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div style="text-align: center">
                                <?php echo e($permissions->links("vendor.pagination.bootstrap-4")); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\helpdesk-main V4\helpdesk-main V2\resources\views/permissions/index.blade.php ENDPATH**/ ?>