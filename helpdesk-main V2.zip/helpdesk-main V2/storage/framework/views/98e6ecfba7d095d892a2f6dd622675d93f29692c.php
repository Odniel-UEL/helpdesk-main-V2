<div class="form-group row">
    <label for="selectedCustomer" class="col-sm-4 col-form-label">Caller</label>
    <div class="col-sm-8">
        <select id="selectedCustomer" wire:model="selectedCustomer" class="form-control">
            <option value="">- SELECT CUSTOMER -</option>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views\livewire\customer-project.blade.php ENDPATH**/ ?>