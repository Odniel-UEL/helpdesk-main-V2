<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Edit User</h1>
        </div>

        <div class="section-body">

            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-unlock"></i> Edit User</h4>
                </div>

                <div class="card-body">
                    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>FIRST NAME</label>
                                <input type="text" name="firstname" value="<?php echo e(old('firstname', $user->firstname)); ?>"
                                    placeholder="Enter the first name"
                                    class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    
                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" style="display: block">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-6">
                                <label>LAST NAME</label>
                                <input type="text" name="lastname" value="<?php echo e(old('lastname', $user->lastname)); ?>"
                                    placeholder="Enter the last name"
                                    class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    
                                <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" style="display: block">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>EMAIL</label>
                            <input type="email" id="email" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                                placeholder="Enter the email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <div id="emailError" class="invalid-feedback" style="display: none">
                                    Invalid email format
                                </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback" style="display: block">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>PASSWORD</label>
                                    <input type="password" name="password" value="<?php echo e(old('password')); ?>"
                                        placeholder="Enter the password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>PASSWORD</label>
                                    <input type="password"  id="password_confirmation" name="password_confirmation"
                                        value="<?php echo e(old('password_confirmation')); ?>"
                                        placeholder="Enter the password confirmation" class="form-control">
                                        <div id="passwordConfirmationError" class="invalid-feedback" style="display: none;">
                                            Passwords do not match
                                        </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-lg-6">
                                <label class="font-weight-bold">ROLE</label>
                                <br/>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input role-checkbox" type="checkbox" name="role[]" value="<?php echo e($role->name); ?>"
                                                id="check-<?php echo e($role->id); ?>" <?php echo e($user->roles->contains($role->id) ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="check-<?php echo e($role->id); ?>">
                                                <?php echo e($role->name); ?>

                                            </label>
                                        </div>
                                        <br/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
    

                            <div class="form-group col-lg-6">
                                <label>CHANGE STATUS</label>
                                <select name="isActive" id="isActive" class="form-control select-status <?php $__errorArgs = ['isActive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                    <option value="">-- Change status --</option>
                                    <option value="1" <?php if($user->isActive == "1"): ?> selected <?php endif; ?>>Active</option>
                                    <option value="0" <?php if($user->isActive == "0"): ?> selected <?php endif; ?>>Inactive</option>
                                </select>
                            </div>
                            
                        </div>

                        <button class="btn btn-primary mr-1 btn-submit" type="submit"><i class="fa fa-paper-plane"></i>
                            UPDATE</button>
                            <button class="btn btn-secondary btn-cancel" type="button" onclick="window.location='<?php echo e(url()->previous()); ?>'">
                                <i class="fa fa-times"></i> CANCEL
                            </button>

                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    // Get the password and confirm password input fields and the error message div
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('password_confirmation');
    const passwordConfirmationError = document.getElementById('passwordConfirmationError');

    // Add event listener to the confirm password field for input event
    confirmPasswordInput.addEventListener('input', validatePasswordConfirmation);

    // Function to validate password confirmation
    function validatePasswordConfirmation() {
        const password = passwordInput.value.trim(); // Get the trimmed password value
        const confirmPassword = confirmPasswordInput.value.trim(); // Get the trimmed confirm password value

        // Check if password and confirm password match
        if (password === confirmPassword) {
            // Hide the error message if passwords match
            passwordConfirmationError.style.display = 'none';
        } else {
            // Show the error message if passwords don't match
            passwordConfirmationError.style.display = 'block';
        }
    }

    document.getElementById('email').addEventListener('input', function() {
        var emailInput = this.value.trim();
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(emailInput)) {
            document.getElementById('email').classList.add('is-invalid');
            document.getElementById('emailError').style.display = 'block';
        } else {
            document.getElementById('email').classList.remove('is-invalid');
            document.getElementById('emailError').style.display = 'none';
        }
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views\users\edit.blade.php ENDPATH**/ ?>