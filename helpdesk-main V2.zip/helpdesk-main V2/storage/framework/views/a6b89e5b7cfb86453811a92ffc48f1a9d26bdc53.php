<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>ERP</title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/school.svg')); ?>" type="image/x-icon">
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/fontawesome/css/all.min.css')); ?>">

    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2-bootstrap4.css')); ?>" />

    <!-- Include Flatpickr CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">

<!-- DataTables Buttons CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">



    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">

    <script src="<?php echo e(asset('assets/modules/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>

    
<!-- Include Flatpickr JS -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

<!-- DataTables Buttons JS -->
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>

<!-- JSZip (for Excel export) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.2.2/jszip.min.js"></script>

<!-- PDFMake (for PDF export) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/vfs_fonts.js"></script>


    <?php echo \Livewire\Livewire::styles(); ?>


</head>

<body style="background: #e2e8f0">
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline mr-auto">
                    <ul class="navbar-nav mr-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i
                                    class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right">

                    <li class="dropdown"><a href="#" data-toggle="dropdown"
                            class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                            <img alt="image" src="<?php echo e(asset('assets/img/avatar/avatar-1.png')); ?>"
                                class="rounded-circle mr-1">
                            <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(auth()->user()->firstname); ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a href="<?php echo e(route('logout')); ?>" style="cursor: pointer" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
                                class="dropdown-item has-icon text-danger">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </ul>
            </nav>
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="index.html">ERP SYSTEM</a>
                    </div>
                    <div class="sidebar-brand sidebar-brand-sm">
                        <a href="index.html">ERP</a>
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">MAIN MENU</li>
                        <li class="<?php echo e(setActive('/dashboard')); ?>">
                            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tickets.index')): ?>
                        <li class="<?php echo e(setActive('/tickets')); ?>">
                            <a class="nav-link" href="<?php echo e(route('tickets.index')); ?>">
                                <i class="fas fa-ticket-alt"></i>
                                <span>Ticket</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.index')): ?>
                        <li class="<?php echo e(setActive('/projects')); ?>">
                            <a class="nav-link" href="<?php echo e(route('projects.index')); ?>">
                                <i class="fas fa-project-diagram"></i>
                                <span>Projects</span>
                            </a>
                        </li> 
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customers.index')): ?>
                        <li class="<?php echo e(setActive('/customers')); ?>">
                            <a class="nav-link" href="<?php echo e(route('customers.index')); ?>">
                                <i class="fas fa-user-tie"></i>
                                <span>Customers</span>
                            </a>
                        </li> 
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('slas.index')): ?>
                        <li class="<?php echo e(setActive('/slas')); ?>">
                            <a class="nav-link" href="<?php echo e(route('slas.index')); ?>">
                                <i class="fas fa-file-medical-alt"></i>
                                <span>SLA</span>
                            </a>
                        </li> 
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.customerWise')): ?>
                        <li class="menu-header">REPORTS</li>
                        <li class="<?php echo e(setActive('/customerReports')); ?>">
                            <a class="nav-link" href="<?php echo e(route('reports.customerWise')); ?>">
                                <i class="fas fa-unlock-alt"></i>
                                <span>Customer wise</span> 
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports.developerWise')): ?>
                        <li class="<?php echo e(setActive('/developerReports')); ?>">
                            <a class="nav-link" href="<?php echo e(route('reports.developerWise')); ?>">
                                <i class="fas fa-unlock-alt"></i>
                                <span>Developer wise</span> 
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.index')): ?>
                        <li class="menu-header">SETTING</li>
                        <li class="<?php echo e(setActive('/permissions')); ?>">
                            <a class="nav-link" href="<?php echo e(route('permissions.index')); ?>">
                                <i class="fas fa-unlock-alt"></i>
                                <span>Permissions</span> 
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index')): ?>
                        <li class="<?php echo e(setActive('/roles')); ?>">
                            <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                                <i class="fas fa-unlock"> </i> 
                                <span>Roles</span> 
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.index')): ?>
                        <li class="<?php echo e(setActive('/user')); ?>">
                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                <i class="fas fa-users"></i> 
                                <span>Users</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('log_users.index')): ?>
                        <li class="<?php echo e(setActive('/user-log')); ?>">
                            <a class="nav-link" href="<?php echo e(route('userlog.index')); ?>">
                                <i class="fas fa-list"></i> 
                                <span>User Logs</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </aside>
            </div>

            <!-- Main Content -->
            <?php echo $__env->yieldContent('content'); ?>

            <footer class="main-footer">
                <div class="footer-left">
                    Copyright &copy; 2024 <div class="bullet"></div> ERP SYSTEM <div class="bullet"></div> All Rights
                    Reserved.
                </div>
                <div class="footer-right">

                </div>
            </footer>
        </div>
    </div>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('assets/modules/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/modules/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/modules/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>
    

    <!-- JS Libraies -->

    <!-- Page Specific JS File -->

    <!-- Template JS File -->
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script>
        //active select2
        // $(document).ready(function () {
        //     $('select').select2({
        //         theme: 'bootstrap4',
        //         width: 'style',
        //     });
        // });

        //flash message
        <?php if(session()-> has('success')): ?>
        swal({
            type: "success",
            icon: "success",
            title: "SUCCEED!",
            text: "<?php echo e(session('success')); ?>",
            timer: 1500,
            showConfirmButton: false,
            showCancelButton: false,
            buttons: false,
        });
        location.reload();
        <?php elseif(session()-> has('error')): ?>
        swal({
            type: "error",
            icon: "error",
            title: "FAIL!",
            text: "<?php echo e(session('error')); ?>",
            timer: 1500,
            showConfirmButton: false,
            showCancelButton: false,
            buttons: false,
        });
        location.reload();
        <?php endif; ?>
    </script>

    <script>
        function isEmpty(input) {
        return input.value.trim() === '';
    }

    // Function to validate a single input field
    function validateField(input) {
        if (isEmpty(input)) {
            input.classList.add('is-invalid');
            return false;
        } else {
            input.classList.remove('is-invalid');
            return true;
        }
    }

    // Function to validate all input fields
    function validateForm() {
        var inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
        var isValid = true;

        inputs.forEach(function(input) {
            if (!validateField(input)) {
                isValid = false;
            }
        });

        return isValid;
    }

    // Add blur event listeners to all input fields
    var inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    inputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            validateField(input);
        });
    });
    </script>

    
<script>
    document.querySelector('.btn-reset').addEventListener('click', function() {
        // Ensure all fields are cleared
        document.querySelector('.form-horizontal').reset();
    });
</script>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views/layouts/app.blade.php ENDPATH**/ ?>