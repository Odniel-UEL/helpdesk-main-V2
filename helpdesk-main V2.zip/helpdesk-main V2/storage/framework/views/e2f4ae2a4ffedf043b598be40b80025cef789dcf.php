<div class="form-group">
    <label>EMAIL</label>
    <input wire:model="email" type="email" placeholder="Enter the email" class="form-control">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
    <div class="invalid-feedback" style="display: block">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views\livewire\user-form.blade.php ENDPATH**/ ?>