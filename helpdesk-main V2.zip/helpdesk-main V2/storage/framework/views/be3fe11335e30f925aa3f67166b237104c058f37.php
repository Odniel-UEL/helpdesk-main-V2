<div>
   <input type="text" wire:model="testmodel">
   <?php echo e($testmodel); ?>

</div>
<?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views\livewire\test.blade.php ENDPATH**/ ?>