<?php $__env->startPush('styles'); ?>
    <link href="css/public/assets/css/EditTicketStyles.css.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        /*
            .incident-container {
              max-width: 800px;
              margin: 50px auto;
              padding: 20px;
              border: 1px solid #ccc;
              border-radius: 5px;
              box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            } */

        h1,
        h2 {
            text-align: center;
        }

        .form-container {
            display: flex;
            justify-content: space-between;
        }

        .form-column {
            flex: 1;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: calc(100% - 2px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .divider {
            border-top: 2px solid #ccc;
            margin: 20px 0;
        }

        .activities-container {
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        .notes-container {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
        }

        .notes-container .form-group {
            margin-bottom: 10px;
        }

        /* Styles for activities */
        .activity-box {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .activity-box p {
            margin: 0;
        }

        .activity-box span {
            font-size: 0.8em;
            color: #777;
        }

        .activity-box {
            position: relative;
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
        }

        .activity-timestamp {
            position: absolute;
            top: 5;
            right: 5;
            font-size: 13px !important;
            color: #999;
        }

        .activity-author {

            font-size: 13px !important;
            color: #999;
        }

        .activity-details {

            margin: 10 0 0 40
        }


        #suggestions {
            position: absolute;
            top: 100%;
            z-index: 1000;
            width: 90%;
            max-height: 200px;
            overflow-y: auto;
            background-color: #fff;
            border: 1px solid #ccc;
            border-top: none;
            border-radius: 0 0 5px 5px;
        }

        .user-suggestion {
            padding: 8px 12px;
            cursor: pointer;
        }

        .user-suggestion:hover {
            background-color: #f0f0f0;
        }
    </style>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Edit Tiket</h1>
            </div>

            <div class="section-body">

                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-folder"></i> Edit tiket</h4>
                    </div>

                    <div class="card-body">

                        <form action="<?php echo e(route('tickets.update', $ticket->id)); ?>" method="POST"
                            enctype="multipart/form-data" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <?php if($ticket->status != 'Closed' && $ticket->status != 'Cancelled'): ?>
                                <div class="mb-5 d-flex justify-content-end">
                                    <button class="btn btn-primary mr-1 btn-submit" type="submit"><i
                                            class="fa fa-paper-plane"></i> SAVE</button>
                                    <button class="btn btn-secondary btn-cancel" type="button"
                                        onclick="window.location='<?php echo e(url()->previous()); ?>'">
                                        <i class="fa fa-times"></i> CANCEL
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="incident-container">
                                <div class="form-container">
                                    <div class="row col-12">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="incident-number" class="col-sm-4 col-form-label">Number:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="ticket_no"
                                                        value="<?php echo e(old('ticket_no', $ticket->number)); ?>" class="form-control"
                                                        readonly />
                                                </div>
                                            </div>

                                            <input type="hidden" name="updated_customer" id="updated_customer"
                                                value="<?php echo e($ticket->customer_id); ?>">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">Caller</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="customer"
                                                        value="<?php echo e($ticket->customer->firstname); ?> <?php echo e($ticket->customer->lastname); ?>"
                                                        class="form-control" readonly>
                                                </div>

                                            </div>

                                            <div class="form-group row" style="display: none">
                                                <label for="openedBy" class="col-sm-4 col-form-label">Opened By:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="openedBy"
                                                        value="<?php echo e(old('openedby', $ticket->openedBy->firstname)); ?>"
                                                        class="form-control" readonly />
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="priority" class="col-sm-4 col-form-label">Priority:</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control select-sla" name="sla_id">
                                                        <option disabled value="">- SELECT SLA -</option>
                                                        <?php $__currentLoopData = $slas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($ticket->sla_id == $sla->id): ?>
                                                                <option value="<?php echo e($sla->id); ?>" selected>
                                                                    <?php echo e($sla->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($sla->id); ?>"><?php echo e($sla->name); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <?php if(auth()->check() && auth()->user()->hasAnyRole('Admin|Tech Lead|Developer|Senior Developer')): ?>
                                                <div class="form-group row">
                                                    <label for="resolutionHours" class="col-sm-4 col-form-label">Resolution
                                                        Hours:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="resolutionHours"
                                                            value="<?php echo e(old('resolutionHours', $ticket->resolutionHours)); ?>"
                                                            class="form-control <?php $__errorArgs = ['resolutionHours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />

                                                        <?php $__errorArgs = ['resolutionHours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback" style="display: block">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label for="state" class="col-sm-4 col-form-label">State:</label>
                                                <div class="col-sm-8">
                                                    <select name="status" id="status"
                                                        class="form-control select-status <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option disabled value="">-- Change status --</option>
                                                        <option value="New"
                                                            <?php if($ticket->status == 'New'): ?> selected <?php endif; ?>>New</option>
                                                        <option value="Assigned"
                                                            <?php if($ticket->status == 'Assigned'): ?> selected <?php endif; ?>>Assigned
                                                        </option>
                                                        <option value="To be Tested"
                                                            <?php if($ticket->status == 'To be Tested'): ?> selected <?php endif; ?>>To be Tested
                                                        </option>
                                                        <option value="To be Deployed"
                                                            <?php if($ticket->status == 'To be Deployed'): ?> selected <?php endif; ?>>To be Deployed
                                                        </option>
                                                        <option value="Closed"
                                                            <?php if($ticket->status == 'Closed'): ?> selected <?php endif; ?>>Closed
                                                        </option>
                                                        <option value="Cancelled"
                                                            <?php if($ticket->status == 'Cancelled'): ?> selected <?php endif; ?>>Cancelled
                                                        </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="project" class="col-sm-4 col-form-label">Project:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="project"
                                                        value="<?php echo e(old('project', $ticket->project->name)); ?>"
                                                        class="form-control" readonly />
                                                </div>
                                            </div>
                                            

                                            <div class="form-group row">
                                                <label for="createdAt" class="col-sm-4 col-form-label">Created:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" name="createdAt"
                                                        value="<?php echo e(old('created_at', $ticket->created_at)); ?>"
                                                        class="form-control" readonly />
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                </div>

                                <div class="description-container col-12 mt-5">
                                    <div class="form-group row">
                                        <label for="problemsummary" class="col-sm-2 col-form-label">Short
                                            Description:</label>
                                        <div class="col-sm-10">
                                            <input type="text"name="problemsummary"
                                                value="<?php echo e(old('problemsummary', $ticket->problemsummary)); ?>"
                                                class="form-control <?php $__errorArgs = ['problemsummary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                <?php if(auth()->check() && auth()->user()->hasRole('Developer')): ?> readonly <?php endif; ?> />

                                            <?php $__errorArgs = ['problemsummary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback" style="display: block">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="problemdetail" class="col-sm-2 col-form-label">Description:</label>
                                        <div class="col-sm-10">
                                            <textarea id="problemdetail" rows="4" name="problemdetail" <?php if(auth()->check() && auth()->user()->hasRole('Developer')): ?> readonly <?php endif; ?>><?php echo e(old('problemdetail', $ticket->problemdetail)); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="notes-container">
                                    <div class="form-group">
                                        <label for="work-notes">Work notes:</label>
                                        <textarea id="worknotes" name="worknotes" rows="3"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="customer-comments">Customer comments:</label>
                                        <textarea id="customer_comments" name="customer_comments" rows="3"></textarea>
                                    </div>
                                </div>

                            </div>
                            
                            

                        </form>
                        <div class="activities-container" id="activities-container">
                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="activity-box">
                                    <span class="activity-author"><?php echo e($activity->user->firstname); ?>

                                        <?php echo e($activity->user->lastname); ?></span>
                                    <?php if($activity instanceof \App\Models\TicketActivity): ?>
                                        <div class="activity-details">
                                            <?php $__currentLoopData = $activity->activity_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!empty($value)): ?>
                                                    <?php if($key === 'Created'): ?>
                                                        <div class="activity-item"><b><?php echo e($key); ?>:
                                                                &nbsp;&nbsp;</b><?php echo e(\Carbon\Carbon::parse($value)->toDateTimeString()); ?>

                                                        </div>
                                                    <?php else: ?>
                                                        <div class="activity-item"><b><?php echo e($key); ?>:
                                                                &nbsp;&nbsp;</b><?php echo e($value); ?></div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php elseif($activity instanceof \App\Models\TicketWorkNote): ?>
                                        <div class="activity-details">
                                            <?php if(!empty($activity->work_notes)): ?>
                                                <div class="activity-item"><b>Work Notes:
                                                        &nbsp;&nbsp;</b><?php echo e($activity->work_notes); ?></div>
                                            <?php endif; ?>
                                            <?php if(!empty($activity->customer_comments)): ?>
                                                <div class="activity-item"><b>Customer Comments:
                                                        &nbsp;&nbsp;</b><?php echo e($activity->customer_comments); ?></div>
                                            <?php endif; ?>
                                        </div>

                                        <span class="activity-timestamp">Notes. <?php echo e($activity->created_at); ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>



                    </div>
                </div>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>

<script>
    window.addEventListener('customer-updated', event => {
        document.getElementById('updated_customer').value = event.detail.selectedCustomer;
    })
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Function to show suggestions
        function showSuggestions(query) {
            $.ajax({
                url: "<?php echo e(route('get.users')); ?>",
                method: 'GET',
                data: {
                    query: query
                },
                success: function(data) {
                    $('#suggestions').empty();
                    data.forEach(function(user) {
                        $('#suggestions').append('<div class="user-suggestion">' + user +
                            '</div>');
                    });
                    $('#suggestions').show(); // Show suggestions
                }
            });
        }

        // Function to hide suggestions
        function hideSuggestions() {
            $('#suggestions').empty().hide();
        }

        // Input event handling for assignee input
        $('#assignee').on('input', function() {
            var query = $(this).val();
            if (query.trim() === '') {
                hideSuggestions();
            } else {
                showSuggestions(query);
            }
        });

        // Click event handling for user suggestions
        $(document).on('click', '.user-suggestion', function() {
            var selectedUser = $(this).text();
            $('#assignee').val(selectedUser);
            hideSuggestions(); // Hide suggestions after selection
        });

        // Focus event handling for assignee input (to show suggestions)
        $('#assignee').on('focus', function() {
            var query = $(this).val();
            if (query.trim() !== '') {
                showSuggestions(query);
            }
        });

        // Click event handling for the document body
        $(document).on('click', function(event) {
            // Check if the clicked element is within the suggestion div or assignee input field
            if (!$(event.target).closest('#suggestions').length && !$(event.target).is('#assignee')) {
                hideSuggestions(); // Hide suggestions if clicked outside
            }
        });
    });
</script>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views/tickets/edit.blade.php ENDPATH**/ ?>