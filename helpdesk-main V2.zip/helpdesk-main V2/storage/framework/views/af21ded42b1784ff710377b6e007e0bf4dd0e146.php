<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Dashboard</h1>
        </div>

        

        <div class="section-body">
          <div class="container">

            <div class="row">
              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon bg-primary">
                    <i class="fa fa-ticket-alt text-white fa-2x"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>This month tickets</h4>
                    </div>
                    <div class="card-body">
                      <?php echo e($report->getMonthlyTickets() ?? '0'); ?>

                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-3 col-md-6 col-sm-6 col-12"> 
                <div class="card card-statistic-1">
                  <div class="card-icon bg-danger">
                    <i class="fa fa-skull-crossbones text-white fa-2x"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>SLA Exceeded Tickets</h4>
                    </div>
                    <div class="card-body">
                      <?php echo e($report->getOverdueTickets('red') ?? '0'); ?>

                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon bg-warning">
                    <i class="fa fa-exclamation-triangle text-white fa-2x"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Approaching SLA</h4>
                    </div>
                    <div class="card-body">
                      <?php echo e($report->getOverdueTickets('yellow') ?? '0'); ?>

                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon bg-success">
                    <i class="fa fa-smile-wink text-white fa-2x"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Completed Tickets</h4>
                    </div>
                    <div class="card-body">
                      <?php echo e($report->getMonthlyDoneTickets() ?? '0'); ?>

                    </div>
                  </div>
                </div>  
              </div>              
            </div>

            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                      <h4><i class="fas fa-clipboard-list"></i> This Month Report </h4>
                  </div>
    
                  <div class="card-body">
                      <div class="table-responsive">
                          <table class="table table-bordered">
                              <thead>
                              <tr>
                                  <th scope="col" style="text-align: center;width: 6%">NO.</th>
                                  <th scope="col">NAME</th>
                                  <th scope="col">ASSIGNED</th>
                                  <th scope="col">EXPIRED</th>
                                  <th scope="col">WARNING</th>
                                  <th scope="col">PENDING</th>
                                  <th scope="col">DONE</th>
                              </tr>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $allReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <th scope="row" style="text-align: center"><?php echo e(++$no); ?></th>
                                      <td><?php echo e($item['name']); ?></td>
                                      <td><span class="badge badge-primary"><?php echo e($item['assigned']); ?></span></td>
                                      <td><span class="badge badge-danger"><?php echo e($item['expired']); ?></span></td>
                                      <td><span class="badge badge-warning"><?php echo e($item['warning']); ?></span></td>
                                      <td><span class="badge badge-dark"><?php echo e($item['pending']); ?></span></td>
                                      <td><span class="badge badge-success"><?php echo e($item['done']); ?></span></td>
                                  </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
                </div>
              </div>
              
              
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Esoft\External Assignments\Degree\Chamalka\helpdesk-main\helpdesk-main V2\resources\views/dashboard.blade.php ENDPATH**/ ?>