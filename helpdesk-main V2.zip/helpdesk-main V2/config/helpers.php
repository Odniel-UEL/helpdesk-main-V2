<?php

/**
 * @param $path
 * @return string
 */
if (!function_exists('setActive')) {
    function setActive($path)
    {
        return Request::is($path . '*') ? ' active' :  '';
    }
}

/**
 * @param $format
 * @param string $tanggal
 * @param string $bahasa
 * @return string|string[]
 */
if (!function_exists('TanggalID')) {
    function TanggalID($format, $tanggal="now", $bahasa="id")
    {
        $en = array("Sun","Mon","Tue","Wed","Thu","Fri","Sat","Jan","Feb",
            "Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
        $id = array("Ming","Sen","Sel","Rab","Kam","Jum","Sab","Jan","Feb",
            "Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des");

        return str_replace($en, $$bahasa, date($format, strtotime($tanggal)));
    }
}